<?
include("../class/layout.class");
include("$DOCUMENT_ROOT/admin/webedit/webedit.lib.php");
include("$DOCUMENT_ROOT/class/mysql.class");

if ($FromYY == ""){
	$before10day = mktime(0, 0, 0, date("m")  , date("d")-20, date("Y"));
	
//	$sDate = date("Y/m/d");
	$sDate = date("Y/m/d", $before10day);
	$eDate = date("Y/m/d");
	
	$startDate = date("Ymd", $before10day);
	$endDate = date("Ymd");
}else{
	$sDate = $FromYY."/".$FromMM."/".$FromDD;
	$eDate = $ToYY."/".$ToMM."/".$ToDD;
	$startDate = $FromYY.$FromMM.$FromDD;
	$endDate = $ToYY.$ToMM.$ToDD;
}

$vdate = date("Ymd", time());
$today = date("Y/m/d", time());
$vyesterday = date("Y/m/d", time()-84600);
$voneweekago = date("Y/m/d", time()-84600*7);
$vtwoweekago = date("Y/m/d", time()-84600*14);
$vfourweekago = date("Y/m/d", time()-84600*28);
$vyesterday = date("Y/m/d",mktime(0,0,0,substr($vdate,4,2),substr($vdate,6,2),substr($vdate,0,4))-60*60*24);
$voneweekago = date("Y/m/d",mktime(0,0,0,substr($vdate,4,2),substr($vdate,6,2),substr($vdate,0,4))-60*60*24*7);
$v15ago = date("Y/m/d",mktime(0,0,0,substr($vdate,4,2),substr($vdate,6,2),substr($vdate,0,4))-60*60*24*15);
$vfourweekago = date("Y/m/d",mktime(0,0,0,substr($vdate,4,2),substr($vdate,6,2),substr($vdate,0,4))-60*60*24*28);
$vonemonthago = date("Y/m/d",mktime(0,0,0,substr($vdate,4,2)-1,substr($vdate,6,2)+1,substr($vdate,0,4)));
$v2monthago = date("Y/m/d",mktime(0,0,0,substr($vdate,4,2)-2,substr($vdate,6,2)+1,substr($vdate,0,4)));
$v3monthago = date("Y/m/d",mktime(0,0,0,substr($vdate,4,2)-3,substr($vdate,6,2)+1,substr($vdate,0,4)));	

if($publish_ix){
	$db = new MySQL();
	
	$sql = "select cp.*,c.cupon_kind from ".TBL_MALLSTORY_CUPON."  c , ".TBL_MALLSTORY_CUPON_PUBLISH." cp 
					where  c.cupon_ix = cp.cupon_ix and publish_ix ='$publish_ix' ";
	
	$db->query($sql);
	$db->fetch();
//print_r($db->dt);
	
	$cupon_ix = $db->dt[cupon_ix];
	$cupon_kind = $db->dt[cupon_kind]."(".$db->dt[cupon_no].")";
	
	
}

?>

<html>
<title>사용자별 쿠폰 발행</title>
<meta http-equiv='Content-Type' content='text/html; charset=euc-kr'>
<LINK REL='stylesheet' HREF='/admin/include/admin.css' TYPE='text/css'>
<LINK REL='stylesheet' HREF='/css/design.css' TYPE='text/css'>
<LINK REL='stylesheet' HREF='/admin/css/design.css' TYPE='text/css'>
<LINK REL='stylesheet' HREF='/admin/common/css/design.css' TYPE='text/css'>
<script language='javascript' src='../include/DateSelect.js'></script>
<script language='javascript'>
	function allCheck(frm){
		if(frm.all.checked == true){
			for(var i=0;i<frm.code.length;i++){
				if(!frm.code[i].disabled){
					frm.code[i].checked = true;
				}
			}
		}else{
			for(var i=0;i<frm.code.length;i++){
				frm.code[i].checked = false;
			}
		}
	}
	
	
function init_date(FromDate,ToDate) {
	var frm = document.member_search;
	
	
	for(i=0; i<frm.FromYY.length; i++) {
		if(frm.FromYY.options[i].value == FromDate.substring(0,4))
			frm.FromYY.options[i].selected=true
	}
	for(i=0; i<frm.FromMM.length; i++) {
		if(frm.FromMM.options[i].value == FromDate.substring(5,7))
			frm.FromMM.options[i].selected=true
	}
	for(i=0; i<frm.FromDD.length; i++) {
		if(frm.FromDD.options[i].value == FromDate.substring(8,10))
			frm.FromDD.options[i].selected=true
	}
	
	
	for(i=0; i<frm.ToYY.length; i++) {
		if(frm.ToYY.options[i].value == ToDate.substring(0,4))
			frm.ToYY.options[i].selected=true
	}
	for(i=0; i<frm.ToMM.length; i++) {
		if(frm.ToMM.options[i].value == ToDate.substring(5,7))
			frm.ToMM.options[i].selected=true
	}
	for(i=0; i<frm.ToDD.length; i++) {
		if(frm.ToDD.options[i].value == ToDate.substring(8,10))
			frm.ToDD.options[i].selected=true
	}
	
}


function onLoad(FromDate, ToDate) {
		var frm = document.member_search;
	
	
	LoadValues(frm.FromYY, frm.FromMM, frm.FromDD, FromDate);
	LoadValues(frm.ToYY, frm.ToMM, frm.ToDD, ToDate);
	
	frm.FromYY.disabled = true;
	frm.FromMM.disabled = true;
	frm.FromDD.disabled = true;
	frm.ToYY.disabled = true;
	frm.ToMM.disabled = true;
	frm.ToDD.disabled = true;	
	
	init_date(FromDate,ToDate);
	
}

function ChangeRegistDate(frm){
	if(frm.regdate.checked){
		frm.FromYY.disabled = false;
		frm.FromMM.disabled = false;
		frm.FromDD.disabled = false;
		frm.ToYY.disabled = false;
		frm.ToMM.disabled = false;
		frm.ToDD.disabled = false;
	}else{
		frm.FromYY.disabled = true;
		frm.FromMM.disabled = true;
		frm.FromDD.disabled = true;
		frm.ToYY.disabled = true;
		frm.ToMM.disabled = true;
		frm.ToDD.disabled = true;		
	}
}


function select_date(FromDate,ToDate,dType) {
	var frm = document.member_search;
	
	if(dType == 1){
		for(i=0; i<frm.FromYY.length; i++) {
			if(frm.FromYY.options[i].value == FromDate.substring(0,4))
				frm.FromYY.options[i].selected=true
		}
		for(i=0; i<frm.FromMM.length; i++) {
			if(frm.FromMM.options[i].value == FromDate.substring(5,7))
				frm.FromMM.options[i].selected=true
		}
		for(i=0; i<frm.FromDD.length; i++) {
			if(frm.FromDD.options[i].value == FromDate.substring(8,10))
				frm.FromDD.options[i].selected=true
		}
		
		
		for(i=0; i<frm.ToYY.length; i++) {
			if(frm.ToYY.options[i].value == ToDate.substring(0,4))
				frm.ToYY.options[i].selected=true
		}
		for(i=0; i<frm.ToMM.length; i++) {
			if(frm.ToMM.options[i].value == ToDate.substring(5,7))
				frm.ToMM.options[i].selected=true
		}
		for(i=0; i<frm.ToDD.length; i++) {
			if(frm.ToDD.options[i].value == ToDate.substring(8,10))
				frm.ToDD.options[i].selected=true
		}
	}
	
}

</script>
<style>

input {border:1px solid #c6c6c6}
</style>
<?
if($mmode == ""){
?>
<body topmargin=0 leftmargin=0 onload="onLoad('<?=$sDate?>','<?=$eDate?>', document.member_search);">
<?
}else{
?>
<body topmargin=0 leftmargin=0 >
<?
}
$db = new MySQL;
$mdb = new MySQL;
$sdb = new MySQL;
$idb = new MySQL;

$max = 10;

if ($page == ''){
	$start = 0;
	$page  = 1;
}else{
	$start = ($page - 1) * $max;
}

?>	

<TABLE cellSpacing=0 cellPadding=0 width="100%" align=center border=0>
	<TR>		
		<td align=center >
		<table border="0" width="100%" cellpadding="0" cellspacing="1" align="center">	
			<tr><td  align=left class='top_orange' colspan=2 ></td></tr>
			<tr height=35 bgcolor=#efefef>
				<td  style='padding:0 0 0 0;' colspan=2> 
					<table width='100%' border='0' cellspacing='0' cellpadding='0' >
						<tr> 
							<td width='10%' height='31' valign='middle' style='font-family:굴림;font-size:16px;font-weight:bold;letter-spacing:-2px;word-spacing:0px;padding-left:10px;' nowrap>
								<img src='/admin/images/icon/sub_title_dot.gif' align=absmiddle> 쿠폰 발급 및 발급현황
							</td>
						
						</tr>
						
					</table>
				</td>
			</tr>
			<tr>
				<td style="padding:10 10 0 10" >
					<table width=100% border=0 cellpadding=0 cellspacing=0>
						
						<tr>
					    <td align='left' colspan=4 style='padding-bottom:20px;'> 
					    	<div class='tab'>
									<table class='s_org_tab'>
									<tr>
										<td class='tab'>
											<table id='tab_01' <?=($mode != "result" ? "class='on'":"")?> >
											<tr>
												<th class='box_01'></th>
												<td class='box_02' onclick="document.location.href='?publish_ix=<?=$publish_ix?>'">쿠폰 발급 하기</td>
												<th class='box_03'></th>
											</tr>
											</table>
											<table id='tab_02' <?=($mode == "result" ? "class='on'":"")?>>
											<tr>
												<th class='box_01'></th>
												<td class='box_02' onclick="document.location.href='?mode=result&publish_ix=<?=$publish_ix?>'">쿠폰발급현황</td>
												<th class='box_03'></th>
											</tr>
											</table>
											
										</td>
										<td class='btn'>						
											
										</td>
									</tr>
									</table>	
								</div>
					    </td>
						</tr>	 
<?
if($mode != "result"){
?>
						<tr><td style="padding-left:10px;"><img src='../images/dot_org.gif' align=absmiddle> <b class="blue"><?=$cupon_kind?></b> 에 대한 쿠폰을 발급합니다.</td></tr>
<?
}else{
?>
						<tr><td style="padding-left:10px;"><img src='../images/dot_org.gif' align=absmiddle> <b class="blue"><?=$cupon_kind?></b> 발급한 사용자 목록입니다</td></tr>
<?
}
?>
						<tr height=30px>
<?
if($mode != "result"){

		
		
		if(!$orderby){
			$orderby = "date";
			$ordertype = "desc";
		}
		
		$where = " where code != '' and mm.gp_ix = mg.gp_ix and gp_level != 0 ";
		
		if($search_type != "" && $search_text != ""){	
			if($search_type == "jumin"){
				$search_text = substr($search_text,0,6)."-".md5(substr($search_text,6,7));
				$where .= " and jumin = '$search_text' ";
			}else{
				$where .= " and $search_type LIKE  '%$search_text%' ";
			}
		}
		
		if($gp_ix != ""){
			$where .= " and mm.gp_ix = '".$gp_ix."' ";
		}	
		
		$startDate = $FromYY.$FromMM.$FromDD;
		$endDate = $ToYY.$ToMM.$ToDD;
			
		if($startDate != "" && $endDate != ""){	
			if($publish_div == "2"){
				$where .= " and  date_format(mm.date,'%Y%m%d') between  $startDate and $endDate ";
			}else if($publish_div == "3"){
				$where .= " and  date_format(mm.recent_order_date,'%Y%m%d') between  $startDate and $endDate ";
			}else if($publish_div == "4"){
				$where .= " and  date_format(mm.last,'%Y%m%d') between  $startDate and $endDate ";
			}
		}
		
		$sql = "select count(*) as total from ".TBL_MALLSTORY_MEMBER." mm , ".TBL_MALLSTORY_GROUPINFO." mg ".$where."  ";
		
		//echo $sql;
		$db->query($sql);
		$db->fetch();
		$total = $db->dt[total];
		
	
		$sql = "select code,name,id,mail, pcs ,perm , mm.gp_ix, date_format(mm.last,'%Y%m%d') as last, date_format(mm.date,'%Y%m%d') as date, 
						date_format(mm.recent_order_date,'%Y%m%d') as recent_order_date, mg.organization_name, mg.gp_name 
						from ".TBL_MALLSTORY_MEMBER." mm , ".TBL_MALLSTORY_GROUPINFO." mg
						".$where."  order by ".$orderby." ".$ordertype."  limit $start,$max ";
		/*
		$sql = "select code,name,id,mail, pcs ,perm , mm.gp_ix, date_format(mm.last,'%Y%m%d') as last, date_format(mm.date,'%Y%m%d') as date, 
						date_format(mm.recent_order_date,'%Y%m%d') as recent_order_date, cr.regist_ix , mg.organization_name, mg.gp_name 
						from ".TBL_MALLSTORY_MEMBER." mm left join ".TBL_MALLSTORY_CUPON_REGIST." cr on mm.code = cr.mem_ix and cr.publish_ix = '$publish_ix'
						, ".TBL_MALLSTORY_GROUPINFO." mg
						".$where." order by ".$orderby." ".$ordertype."  limit $start,$max ";
		*/
		$db->query($sql);
		//echo $sql;
	

//echo $sql;	
	
?>
							<td style="padding-left:10px;padding-top:10px"> 
								<table class="box_shadow" style='width:100%;' >
								<tr>
									<th class="box_01"></th>
									<td class="box_02"></td>
									<th class="box_03"></th>
								</tr>
								<tr>
									<th class="box_04"></th>
									<td class="box_05" align=center style='padding: 0 5 0 5'>					
										<form name='member_search' method='get' style="display:inline;">
										<input type='hidden' name='dupe_check' value=''>
										<input type='hidden' name='publish_ix' value=<?=$publish_ix?>>
										<input type='hidden' name='orderby' value='<?=$orderby?>'>			
										<input type='hidden' name='ordertype' value='<?=$ordertype?>'>		
										<input type='hidden' name='mode' value='search'>
										<input type='hidden' name='act' value='regist_search_update'>	
										<table border="0" cellspacing="1" cellpadding="3" width='100%'>
											<col width='100'>
											<col width='*'>
											<col width='100'>
											<col width='250'>
											<tr height="30" valign="middle">
												<td bgcolor='#efefef'  align="center"> <b>회원검색</b></td>
												<td >
													<select name='search_type'>
														<option value='id' <?=($search_type == "id" ? "selected":"")?>> 아이디</option>
														<option value='name' <?=($search_type == "name" ? "selected":"")?>> 이름 </option>
														<option value='pcs' <?=($search_type == "pcs" ? "selected":"")?>> 핸드폰 </option>
														<option value='mail' <?=($search_type == "mail" ? "selected":"")?>> 이메일 </option>
													</select>
													<input type="text" class="input" name="search_text" style="height:21px;width:200px;" size="20" value='<?=$search_text?>'>
												</td>									
												<td bgcolor='#efefef'  align="center"> <b>회원그룹</b></td>
												<td >
													<?=makeGroupSelectBox($mdb,"gp_ix",$gp_ix)?>
												</td>
												<td><!--input type="image" src='../image/search01.gif' align=absmiddle style="border:0px;"--></td>
											</tr>
											<tr><td colspan=7 background='../image/dot.gif'></td></tr>
											<tr height="30" valign="middle">
												<td bgcolor='#efefef' align="center"  ><b>발급조건</b></td>
												<td colspan=3>
													<input type='radio' name='publish_div' id='publish_div_1' onFocus='this.blur();' align='middle' value='1' style='border:0px;' <?=CompareReturnValue($publish_div,'1',' checked')?>><label for='publish_div_1'>모두보기</label>&nbsp;
                          <input type='radio' name='publish_div' id='publish_div_2' onFocus='this.blur();' align='middle' value='2' style='border:0px;' <?=CompareReturnValue($publish_div,'2',' checked')?>><label for='publish_div_2'>신규회원가입</label>&nbsp;
                          <input type='radio' name='publish_div' id='publish_div_3' onFocus='this.blur();' align='middle' value='3' style='border:0px;' <?=CompareReturnValue($publish_div,'3',' checked')?>><label for='publish_div_3'>최근구매회원</label>
                          <input type='radio' name='publish_div' id='publish_div_4' onFocus='this.blur();' align='middle' value='4' style='border:0px;' <?=CompareReturnValue($publish_div,'4',' checked')?>><label for='publish_div_4'>최근방문회원</label>
												</td>
											</tr>
											<tr><td colspan=7 background='../image/dot.gif'></td></tr>
											<tr height=10>
                          <td bgcolor='#efefef' rowspan=2 align=center><label for='regdate'><b>일자</b></label><input type='checkbox' name='regdate' id='regdate' value='1' onclick='ChangeRegistDate(document.member_search);'></td>
                          <td align=left colspan=3 style='padding-left:5px;'>
                              <table cellpadding=0 cellspacing=1 border=0 bgcolor=#ffffff>
                                  <tr>
                                      <td width=200 nowrap><SELECT onchange=javascript:onChangeDate(this.form.FromYY,this.form.FromMM,this.form.FromDD) name=FromYY ></SELECT> 년 <SELECT onchange=javascript:onChangeDate(this.form.FromYY,this.form.FromMM,this.form.FromDD) name=FromMM></SELECT> 월 <SELECT name=FromDD></SELECT> 일 </TD>
                                      <td width=20 align=center> ~ </TD>
                                      <td width=200 nowrap><SELECT onchange=javascript:onChangeDate(this.form.ToYY,this.form.ToMM,this.form.ToDD) name=ToYY></SELECT> 년 <SELECT onchange=javascript:onChangeDate(this.form.ToYY,this.form.ToMM,this.form.ToDD) name=ToMM></SELECT> 월 <SELECT name=ToDD></SELECT> 일</TD>
                                      <td>
                                          
                                      </td>
                                  </tr>
                              </table>
                          </td>
                      </tr>
                      <tr height="10" valign="middle">                      	
												<td align="left" style='padding-left:5px;' colspan=3>
													<a href="javascript:select_date('<?=$voneweekago?>','<?=$today?>',1);"><img src='../image/b_btn_s_1week01.gif'></a>
                          <a href="javascript:select_date('<?=$v15ago?>','<?=$today?>',1);"><img src='../image/b_btn_s_15day01.gif'></a>
                          <a href="javascript:select_date('<?=$vonemonthago?>','<?=$today?>',1);"><img src='../image/b_btn_s_1month01.gif'></a>
                          <a href="javascript:select_date('<?=$v2monthago?>','<?=$today?>',1);"><img src='../image/b_btn_s_2month01.gif'></a>
                          <a href="javascript:select_date('<?=$v3monthago?>','<?=$today?>',1);"><img src='../image/b_btn_s_3month01.gif'></a>
												</td>
											</tr>
										</table>
										
									</td>
									<th class="box_06"></th>
								</tr>
								<tr>
									<th class="box_07"></th>
									<td class="box_08"></td>
									<th class="box_09"></th>
								</tr>
								</table>			
						<!--
								검색 : 
								<select name='search_type'>
									<option value='id'> 아이디</option>
									<option value='name'> 이름</option>
								</select> <input type='text' name='search_text'> <img src='../images/btn/ok.gif' style="vertical-align:middle" onclick="searchGo('<?=$publish_ix?>')">
								-->
							</td>
						</tr>
						<tr >
                <td colspan=5 align=center  style='padding:10 0 0 0'>
                    <input type='image' src='../image/bt_search.gif' border=0 style='border:0px;'>
                </td>
            </tr>
            </form>
						<tr height=20 align=right>
							<td style="padding-top:10px"> 정렬 : 
							<b class=small>이름</b>
							<a href='cupon_register_user.php?publish_ix=<?=$publish_ix?>&orderby=name&ordertype=asc'><img src='../image/orderby_desc.gif' border=0 align=absmiddle title='가나다순'></a>
							<a href='cupon_register_user.php?publish_ix=<?=$publish_ix?>&orderby=name&ordertype=desc'><img src='../image/orderby_asc.gif' border=0 align=absmiddle title='가나다역순'></a>
							<b class=small>아이디</b>
							<a href='cupon_register_user.php?publish_ix=<?=$publish_ix?>&orderby=id&ordertype=asc'><img src='../image/orderby_desc.gif' border=0 align=absmiddle title='abcd순'></a>
							<a href='cupon_register_user.php?publish_ix=<?=$publish_ix?>&orderby=id&ordertype=desc'><img src='../image/orderby_asc.gif' border=0 align=absmiddle title='abcd역순'></a>
							<b class=small>등록일</b>
							<a href='cupon_register_user.php?publish_ix=<?=$publish_ix?>&orderby=date&ordertype=desc'><img src='../image/orderby_desc.gif' border=0 align=absmiddle title='최근등록순'></a>
							<a href='cupon_register_user.php?publish_ix=<?=$publish_ix?>&orderby=date&ordertype=asc'><img src='../image/orderby_asc.gif' border=0 align=absmiddle title='최근등록역순'></a>

							</td>
						</tr>		
						<form name='cupon_pop' method='post' action='cupon.act.php'>
						<input type='hidden' name='publish_ix' value=<?=$publish_ix?>>
						<input type='hidden' name='act' value='regist_update'>				
						<tr>							
							<td style="padding:10px 0px 0px 10px;" valign=top>								
								<table width=100% border=0 cellpadding=0 cellspacing=0>
									<col width='30'>
									<col width='70'>
									<col width='80'>
									<col width='*'>
									<col width='100'>
									<col width='100'>
									<col width='100'>
									<col width='100'>
									<col width='80'>
									<tr height=30 bgcolor=#e5e5e5 align=center>
										<td class="s_td"><input type='checkbox' name='all' style="border:0" id='code' onclick="allCheck(document.cupon_pop)"></td>
										<td class="m_td">이름</td>
										<td class="m_td">아이디</td>
										<td class="m_td">이메일</td>
										<td class="m_td">핸드폰</td>
										<td class="m_td">최근방문일</td>
										<td class="m_td">최근구매일</td>
										<td class="m_td">회원가입</td>
										<td class="e_td">회원그룹</td>
									</tr>
									
								<?
									for($i=0;$i < $db->total;$i++){
										$db->fetch($i);
								?>
									<tr>
										<td align=center style="padding-top:5px"><input type='checkbox' name='code[]' id='code' value="<?=$db->dt[code]?>" style="border:0" <?=($db->dt[regist_ix] ? "title='이미 등록된 사용자 입니다.' disabled":"")?>></td>
										<td align=center style="padding-top:5px"><?=$db->dt[name]?></td>
										<td align=center style="padding-top:5px"><?=$db->dt[id]?></td>
										<td align=center style="padding-top:5px"><?=$db->dt[mail]?></td>
										<td align=center style="padding-top:5px"><?=$db->dt[pcs]?></td>
										<td align=center style="padding-top:5px"><?=$db->dt[last]?></td>
										<td align=center style="padding-top:5px"><?=$db->dt[recent_order_date]?></td>
										<td align=center style="padding-top:5px"><?=$db->dt[date]?></td>
										<td align=center style="padding-top:5px"><span alt='<?=$db->dt[organization_name]?>'><?=$db->dt[gp_name]?></span></td>
									</tr>
									<tr><td colspan=9 background='../image/dot.gif'></td></tr>
								<?
									}
								?>
									<tr><td colspan=9 align=right style='padding:10 0;letter-spacing:0'><?=page_bar($total, $page, $max,"&publish_ix=".$publish_ix."&mode=".$mode."&search_type=".$search_type."&search_text=".$search_text."&orderby=$orderby&ordertype=$ordertype&publish_div=$publish_div&gp_ix=$gp_ix&FromYY=$FromYY&FromMM=$FromMM&FromDD=$FromDD&ToYY=$ToYY&ToMM=$ToMM&ToDD=$ToDD","")?></td></tr>
									
								</table>							
							</td>
						</tr>
						<tr>
							<td style="padding:5 5 5 10" align=left>
								<a href='javascript:document.cupon_pop.submit();'><img src='../image/btn_selected_cupon_reg.gif' align=absmiddle  border=0></a>
								<? if($mode == "search"){?>
								&nbsp;&nbsp;&nbsp;<a href="javascript:document.member_search.action='cupon.act.php';document.member_search.submit();"><img src='../image/btn_searched_cupon_reg.gif' align=absmiddle border=0></a> <input type='checkbox' name='dupe_check' id='dupe_check' onclick="if(this.checked){document.member_search.dupe_check.value=this.value}else{document.member_search.dupe_check.value=''}" style='border:0px;' value='1'><label for='dupe_check'>중복체크 하지 않음</label>
								<?}?>
							</td>
						</tr>
						
						</form>
					</table>
				</td>
<?
}else if($mode == "result"){
?>
				<form name='list' method='POST' action='cupon.act.php'>
				<input type='hidden' name='publish_ix' value="<?=$publish_ix?>">
				<input type='hidden' name='act' value='regist_delete'>
				<td style="border-left:1px solid #eaeaea;width:50%;padding-top:10px;padding-left:10px" valign=top>
					<table width=100% border=0 cellpadding=0 cellspacing=0>
						<col width='30'>
						<col width='50'>
						<col width='80'>
						<col width='*'>
						<col width='130'>
						<col width='70'>
						<tr height=30 align=center>
							<td class="s_td"><input type='checkbox' name='all' id='code'  style="border:0" onclick="allCheck(document.list)"></td>
							<td class="m_td">이름</td>
							<td class="m_td">아이디</td>
							<td class="m_td">사용기간</td>
							<td class="m_td">등록일자</td>
							<td class="e_td">사용여부</td>
						</tr>
						<?
$sql = "select count(*) as total from mallstory_cupon_regist a, ".TBL_MALLSTORY_MEMBER."  b 
				where a.publish_ix = '".$publish_ix."' and a.mem_ix = b.code ;";
						//	echo $sql;
							
$mdb->query($sql);
$mdb->fetch();
$total = $mdb->dt[total];
							
$sql = "select a.mem_ix,b.name,b.id, a.regdate, b.mail, a.use_yn ,a.use_sdate, a.use_date_limit,
				case when (a.use_sdate <= ".date("Ymd")." and ".date("Ymd")." <= a.use_date_limit) then 1 else 0 end use_priod_yn
				from mallstory_cupon_regist a, ".TBL_MALLSTORY_MEMBER."  b 
				where a.publish_ix = '".$publish_ix."' and a.mem_ix = b.code limit $start,$max ";
//echo $sql;

$mdb->query($sql);
							
							if($mdb->total){
							for($i=0;$i<$mdb->total;$i++){
								$mdb->fetch($i);
						?>
						<tr height=30 align=center>
							<td ><input type='checkbox' name='code[]' style="border:0px" id='code' value="<?=$mdb->dt[mem_ix]?>"  <?=($mdb->dt[use_yn] == 0 ? "":"disabled");?>></td>
							<td ><?=$mdb->dt[name]?></td>
							<td ><?=$mdb->dt[id]?></td>
							<td ><?=ChangeDate($mdb->dt[use_sdate],"Y-m-d")."-".ChangeDate($mdb->dt[use_date_limit],"Y-m-d")?></td>
							<td ><?=$mdb->dt[regdate]?></td>
							<td title='<?=$mdb->dt[use_sdate]?>~<?=$mdb->dt[use_date_limit]?>'><?//($mdb->dt[use_yn] == 0 ? "미사용":"사용");?>
							<?
							if($mdb->dt[use_yn] == 0){							
								if($mdb->dt[use_sdate] <= date("Ymd") && date("Ymd") <= $mdb->dt[use_date_limit]){
									echo "사용가능";
								}else if($mdb->dt[use_sdate] > date("Ymd")){
									echo "사용대기";
								}else{
									echo "기간만료";
								}
							}else{
								echo "사용완료";
							}
							?>	
							</td>
						</tr>
						<tr><td colspan=7 background='../image/dot.gif'></td></tr>
						<?
							}
						}else{
						?>
						<tr height=50><td colspan=7 align=center>등록된 사용자가 없습니다.</td></tr>
						<tr><td colspan=7 background='../image/dot.gif'></td></tr>
						<?
						}
						
						
						?>
						<tr><td colspan=8 align=right style='padding:10 0;letter-spacing:0'><?=page_bar($total, $page, $max,"&publish_ix=".$publish_ix."&mode=".$mode,"")?></td></tr>
						<tr>
							<td colspan=7 style="padding:5 5 5 10" align=left>
								<a href='javascript:document.list.submit();'>선택회원 발급취소</a>
							</td>
						</tr>
					</table>
<?
$help_text = "
<table cellpadding=0 cellspacing=0 class='small' >
	<col width=8>
	<col width=*>
	<tr><td ><img src='/admin/image/icon_list.gif' ></td><td class='small' >쿠폰 <b class='blue small'>".$cupon_kind."</b> 에 대한 쿠폰 발급 목록 입니다.</td></tr>
	<tr><td valign=top><img src='/admin/image/icon_list.gif' ></td><td class='small' >삭제를 원하시는 목록을 선택하여 발급 취소 할 수 있습니다. 단 이미 사용한 쿠폰은 삭제 하실 수 없습니다.</td></tr>
	<tr><td valign=top><img src='/admin/image/icon_list.gif' ></td><td class='small' >같은 쿠폰은 중복 발급할 수 없습니다.</td></tr>
</table>
";


echo HelpBox("쿠폰발급", $help_text);
?>
				</td>
				</form>
<?
}
?>
			</tr>
			<tr>
				<td style="padding-top:10px" align=center><a href='javascript:self.close();'><img src='../image/close.gif' style="border:0"></a></td>
			</tr>
		</table>
		</td>
		
	</tr>
	
</TABLE>

<IFRAME id=act name=act src="" frameBorder=0 width=0 height=0 scrolling=no ></IFRAME>	
</body>
</html>