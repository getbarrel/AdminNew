<?
include("../class/layout.class");
$db = new MySQL();

if(!$publish_ix && $regist_ix){
	$sql = "Select publish_ix from ".TBL_MALLSTORY_CUPON_REGIST." cr  where  regist_ix ='$regist_ix' ";
	$db->query($sql);
	$db->fetch();
	$publish_ix = $db->dt[publish_ix];
}

if($publish_ix){
	
	$sql = "Select cp.*, m.id, m.name from ".TBL_MALLSTORY_CUPON_PUBLISH." cp left join ".TBL_MALLSTORY_MEMBER." m on cp.mem_ix = m.code where  publish_ix ='$publish_ix' ";
	$db->query($sql);
	
	
	$db->fetch();
//print_r($db->dt);
	
	$cupon_ix = $db->dt[cupon_ix];
	$use_date_type = $db->dt[use_date_type];
	$publish_condition_price = $db->dt[publish_condition_price];
	$use_product_type = $db->dt[use_product_type];
	$mem_ix = $db->dt[mem_ix];
	$publish_date_differ = $db->dt[publish_date_differ];
	$publish_date_type = $db->dt[publish_date_type];
	$regist_date_type = $db->dt[regist_date_type];
	$regist_date_differ = $db->dt[regist_date_differ];
	
	$publish = "publish_update";
	
	$publish_type = $db->dt[publish_type];
	if($publish_type == 1){
		$mem_id = $db->dt[name]."(".$db->dt[id].")";
	}
	
//	$sDate = date("Y/m/d");
	$sDate = substr($db->dt[use_sdate],0,4)."/".substr($db->dt[use_sdate],4,2)."/".substr($db->dt[use_sdate],6,2);
	$eDate = substr($db->dt[use_edate],0,4)."/".substr($db->dt[use_edate],4,2)."/".substr($db->dt[use_edate],6,2);
	
	$startDate = $db->dt[use_sdate];
	$endDate = $db->dt[use_edate];
}else{

	$use_date_type = "3";
	$use_product_type = "1";
	$publish = "publish";
	$publish_type = "2";
	
	$before10day = mktime(0, 0, 0, date("m")  , date("d")+10, date("Y"));
	
//	$sDate = date("Y/m/d");
	$sDate = date("Y/m/d");
	$eDate = date("Y/m/d", $before10day);
	
	$startDate = date("Ymd", $before10day);
	$endDate = date("Ymd");

}

$Script = "
<style type='text/css'>
  div#drop_relation_product { width:100%;height:100%;overflow:auto;padding:1px;border:1px solid silver }
  div#drop_relation_product.hover { border:5px dashed #aaa; background:#efefef; }
  table.tb {width:100%;cursor:move;}
</style>
<script src='../js/prototype.js' type='text/javascript'></script>
<script src='../js/scriptaculous.js' type='text/javascript'></script>
<script language='javascript' src='../include/DateSelect.js'></script>
<script language='javascript' src='cupon.js'></script>
<script type='text/javascript' src='relationAjax.js'></script>
<script  id='dynamic'></script>
<script language=javascript>
function CheckCuponInfo(frm){
	
	if(frm.cupon_ix.value == ''){
		alert('쿠폰종류가 선택되지 않았습니다. 쿠폰종류를 선택해주세요');	
		//frm.cupon_ix.focus();
		return false;
	}
	
	if(frm.use_date_type[1].checked){
		if(frm.publish_date_differ.value.length < 1){
			alert('발행일로부터의 사용기간을 입력해주세요');	
			frm.publish_date_differ.focus();
			return false;
		}
	}else if(frm.use_date_type[2].checked){
		if(frm.regist_date_differ.value.length < 1){
			alert('등록일로부터의 사용기간을 입력해주세요');	
			frm.regist_date_differ.focus();
			return false;
		}
	}
	
	
	       
	if(frm.publish_condition_price.value.length < 1){
		alert('결제가격 조건을 입력해 주세요 ');	
		frm.publish_condition_price.focus();
		return false;
	}
	
	if(frm.publish_type.value == '1' && frm.mem_ix.value == ''){
		alert('지정발행의 경우 사용자를 선택하셔야 합니다. ');	
		frm.mem_id.focus();
		return false;
	}
	
	
	
	
		
	return true;
}


function init(){

	var frm = document.form_cupon;		
	onLoad('$sDate','$eDate');
	
	/*
	frm.FromYY.disabled = true;
	frm.FromMM.disabled = true;
	frm.FromDD.disabled = true;
	frm.ToYY.disabled = true;
	frm.ToMM.disabled = true;
	frm.ToDD.disabled = true;
	*/
}
function categoryadd()
{
	var ret;
	var str = new Array();
	var obj = document.form_cupon.cid;
	
	for (i=0;i<obj.length;i++){
		if (obj[i].value){
			str[str.length] = obj[i][obj[i].selectedIndex].text;
			ret = obj[i].value;
		}
	}
	if (!ret){
		alert('카테고리를 선택해주세요');
		return;
	}
	var cate = document.all._category;
	for(i=1;i < cate.length;i++){
		//alert(ret +'=='+ cate[i].value);
		if(ret == cate[i].value){
			alert('이미등록된 카테고리 입니다.');
			return;
		}
	}
	
	var obj = document.getElementById('objCategory');
	oTr = obj.insertRow();
	oTr.id = 'num_tr';
	oTr.height = \"23\";
	oTd = oTr.insertCell();
	oTd.className = 'table_td_white small';
	oTd.innerHTML = \"<input type=text name=category[] id='_category' value='\" + document.form_cupon.selected_cid.value + \"' style='display:none'><input type=text name=depth[] value='\" + document.form_cupon.selected_depth.value + \"' style='display:none'>\";
	oTd = oTr.insertCell();
	oTd.className = 'table_td_white small';
	//oTd.innerHTML = \"<input type=radio name=basic value='\" + oTr.rowIndex + \"'>\";
	oTd = oTr.insertCell();
	oTd.id = \"currPosition\";
	oTd.className = 'table_td_white small ';
	oTd.innerHTML = str.join(\" > \");
	oTd = oTr.insertCell();
	oTd.className = 'table_td_white small';
	oTd.innerHTML = \" <a href='javascript:void(0)' onClick='category_del(this.parentNode.parentNode)'><img src='../images/i_close.gif' border=0></a>\";
}
function category_del(el)
{
	idx = el.rowIndex;
	var obj = document.getElementById('objCategory');
	obj.deleteRow(idx);
}
function loadCategory(sel,target) {
	//alert(target);
	var trigger = sel.options[sel.selectedIndex].value;	
	var form = sel.form.name;
	var depth = sel.depth;
	//if(depth == 2){
	//document.write('category.load.php?form=' + form + '&trigger=' + trigger + '&depth='+depth+'&target=' + target);
	//}
	//alert(target);
	dynamic.src = '../product/category.load.php?form=' + form + '&trigger=' + trigger + '&depth='+depth+'&target=' + target;
	
}
</script>";


$vdate = date("Ymd", time());
$today = date("Y/m/d", time());
$vyesterday = date("Y/m/d", time()-84600);
$voneweekafter = date("Y/m/d", time()+84600*7);
$vtwoweekafter = date("Y/m/d", time()+84600*14);
$vfourweekafter = date("Y/m/d", time()+84600*28);
$vyesterday = date("Y/m/d",mktime(0,0,0,substr($vdate,4,2),substr($vdate,6,2),substr($vdate,0,4))+60*60*24);
$voneweekafter = date("Y/m/d",mktime(0,0,0,substr($vdate,4,2),substr($vdate,6,2),substr($vdate,0,4))+60*60*24*7);
$v15after = date("Y/m/d",mktime(0,0,0,substr($vdate,4,2),substr($vdate,6,2),substr($vdate,0,4))+60*60*24*15);
$vfourweekafter = date("Y/m/d",mktime(0,0,0,substr($vdate,4,2),substr($vdate,6,2),substr($vdate,0,4))+60*60*24*28);
$vonemonthafter = date("Y/m/d",mktime(0,0,0,substr($vdate,4,2)+1,substr($vdate,6,2)+1,substr($vdate,0,4)));
$v2monthafter = date("Y/m/d",mktime(0,0,0,substr($vdate,4,2)+2,substr($vdate,6,2)+1,substr($vdate,0,4)));
$v3monthafter = date("Y/m/d",mktime(0,0,0,substr($vdate,4,2)+3,substr($vdate,6,2)+1,substr($vdate,0,4)));	


$Contents = "
<table width='100%' border='0' cellpadding='0' cellspacing='0'>
  <!--- // 쿠폰정보 ------------------------------------------------------------------------->
  <tr>
	<td align='left' colspan=6 style='padding:0 0 10 0;'> ".GetTitleNavigation("쿠폰 발행", "마케팅지원 > 쿠폰 발행 ")."</td>
  </tr> 
  <tr>
	    <td align='left' colspan=4 style='padding-bottom:20px;'> 
	    	<div class='tab'>
					<table class='s_org_tab'>
					<tr>
						<td class='tab'>
							<table id='tab_01' class='on'>
							<tr>
								<th class='box_01'></th>
								<td class='box_02'  ><a href='cupon_publish.php'>쿠폰발행</a></td>
								<th class='box_03'></th>
							</tr>
							</table>
							<table id='tab_02' >
							<tr>
								<th class='box_01'></th>
								<td class='box_02' ><a href='cupon_publish_list.php'>쿠폰발행 목록</a></td>
								<th class='box_03'></th>
							</tr>
							</table>
							
						</td>
						<td style='width:600px;text-align:right;vertical-align:bottom;padding:0 0 10 0'>						
							
						</td>
					</tr>
					</table>	
				</div>
	    </td>
	</tr>	 
  <tr>
    <td bgcolor='white'><font class='orange16'>쿠폰 발행</font>&nbsp;(여러명일때 아이디는 ',' 또는 ';' 로 구분)</td>
  </tr>    
  <tr>
    <td height='10'></td>
  </tr>
  <tr>
    <td valign='top'>
    	<form name='form_cupon' onsubmit='return CheckCuponInfo(this)' method='post'  action='cupon.act.php' target='act'>
  		<input type=hidden name='act' value='".$publish."'>
  		<input type=hidden name='mmode' value='".$mmode."'>
  		<input type=hidden name='publish_ix' value='".$publish_ix."'>  		
      <table width='100%' border='0' cellpadding='10' cellspacing='1' bgcolor='#E9E9E9'>        
        <tr bgcolor='#FAFAFA'>          
          <td width=120 bgcolor='white'>쿠폰종류</td>
          <td>".SelectCuponKind($cupon_ix)."
          	<br><img src='../image/0.gif' width='1' height='1'></td>
        </tr>
        <tr bgcolor='#FAFAFA'>          
          <td bgcolor='white'>사용기간</td>
          <td>
          	
          	<table cellpadding=0 cellspacing=2 border=0 >		
				<tr>				
					<td><input type='radio' name='use_date_type' id='use_date_type_3' onFocus='this.blur();' align='absmiddle' value=3 ".($use_date_type == 3 ? "checked":"")."><label class='blue' for='use_date_type_3'>사용기간지정</label>&nbsp;</td>	
					<TD width=200 nowrap><SELECT onchange=javascript:onChangeDate(this.form.FromYY,this.form.FromMM,this.form.FromDD) name=FromYY ></SELECT> 년 <SELECT onchange=javascript:onChangeDate(this.form.FromYY,this.form.FromMM,this.form.FromDD) name=FromMM></SELECT> 월 <SELECT name=FromDD></SELECT> 일 </TD>
					<TD width=20 align=center> ~ </TD>
					<TD width=200 nowrap><SELECT onchange=javascript:onChangeDate(this.form.ToYY,this.form.ToMM,this.form.ToDD) name=ToYY></SELECT> 년 <SELECT onchange=javascript:onChangeDate(this.form.ToYY,this.form.ToMM,this.form.ToDD) name=ToMM></SELECT> 월 <SELECT name=ToDD></SELECT> 일</TD>
				</tr>
				<td>					
					<TD colspan=3 align=left>
						<a href=\"javascript:select_date('$voneweekafter','$today',1);\"><img src='../image/b_btn_s_1week01.gif'></a>
						<a href=\"javascript:select_date('$v15after','$today',1);\"><img src='../image/b_btn_s_15day01.gif'></a>
						<a href=\"javascript:select_date('$vonemonthafter','$today',1);\"><img src='../image/b_btn_s_1month01.gif'></a>
						<a href=\"javascript:select_date('$v2monthafter','$today',1);\"><img src='../image/b_btn_s_2month01.gif'></a>
						<a href=\"javascript:select_date('$v3monthafter','$today',1);\"><img src='../image/b_btn_s_3month01.gif'></a>
					</TD>
				</tr>		
			</table>	
          	<br>
          	<input type='radio' name='use_date_type' id='use_date_type_1'  onFocus='this.blur();' align='absmiddle' value=1 ".($use_date_type == 1 ? "checked":"").">
          	<label class='blue' for='use_date_type_1'>발행일로부터</label>&nbsp;(&nbsp;<input type='text' id='fuse_date1' name='publish_date_differ' value='".($use_date_type == 1 ? $publish_date_differ:"")."' class='input_r' maxlength='3' style='filter: blendTrans(duration=0.5); height: 20px; width: 20px'  onFocus=\"FIn(fuse_date1,'#FFD323',0)\" onFocusOut=\"FOut(fuse_date1,'',0)\"   align='absmiddle'>
          	<input type='radio' name='publish_date_type' onFocus='this.blur();' align='absmiddle' value=1 ".($publish_date_type == 1 ? "checked":"").">년&nbsp;
          	<input type='radio' name='publish_date_type' onFocus='this.blur();' align='absmiddle' value=2 ".($publish_date_type == 2 ? "checked":"").">개월&nbsp;
          	<input type='radio' name='publish_date_type' onFocus='this.blur();' align='absmiddle' value=3 ".($publish_date_type == 3 ? "checked":"").">일&nbsp;)&nbsp;간 사용 가능.<br>
          	
          	<input type='radio' name='use_date_type' id='use_date_type_2'  onFocus='this.blur();' align='absmiddle' value=2 ".($use_date_type == 2 ? "checked":"").">
          	<label class='blue' for='use_date_type_2'>발급일로부터</label>&nbsp;(&nbsp;<input type='text' id='fuse_date2' name='regist_date_differ' value='".($use_date_type == 2 ? $regist_date_differ:"")."' class='input_r' maxlength='3' style='filter: blendTrans(duration=0.5); height: 20px; width: 20px' onFocus=\"FIn(fuse_date2,'#FFD323',0)\" onFocusOut=\"FOut(fuse_date2,'',0)\" align='absmiddle'>
          	<input type='radio' name='regist_date_type' onFocus='this.blur();' align='absmiddle' value=1 ".($regist_date_type == 1 ? "checked":"").">년&nbsp;
          	<input type='radio' name='regist_date_type' onFocus='this.blur();' align='absmiddle' value=2 ".($regist_date_type == 2 ? "checked":"").">개월&nbsp;
          	<input type='radio' name='regist_date_type' onFocus='this.blur();' align='absmiddle' value=3 ".($regist_date_type == 3 ? "checked":"").">일&nbsp;)&nbsp;간 사용 가능.<br>
          	<input type='radio' name='use_date_type' id='use_date_type_9'  onFocus='this.blur();' align='absmiddle' value=9 ".($use_date_type == 9 ? "checked":"").">
          	<label class='blue' for='use_date_type_9'>사용하지 않음</label>
          	</td>
        </tr>
        <tr bgcolor='#FAFAFA'>
          <td bgcolor='white' rowspan=2>사용가능상품</td>
          <td style='line-height:200%'>
          	결제가격이 <input type='text' id='fprice' name='publish_condition_price' value='$publish_condition_price' class='input_r' style='height: 20px; width: 70px; filter: blendTrans(duration=0.5)' onFocus=\"FIn(fprice,'#FFD323',0)\" onFocusOut=\"FOut(fprice,'',0)\"  align='absmiddle'>&nbsp;원&nbsp;이상인 상품에 사용가능<br>
          	(0 원을 입력하시면  가격제한 없음)
          </td>
        </tr>
        <tr bgcolor='#FAFAFA'>
			  	<td >
			  	<input type='radio' name='use_product_type' id='use_product_type_1' onclick=\"$('relation_brand_area').style.display='none';$('relation_product_area').style.display='none';$('relation_category_area').style.display='none';\" onFocus='this.blur();' align='absmiddle' value=1 ".($use_product_type == 1 ? "checked":"")."><label class='blue' for='use_product_type_1'>전체 상품에 발급합니다</label><br>
			  	<input type='radio' name='use_product_type' id='use_product_type_4' onclick=\"$('relation_brand_area').style.display='block';$('relation_category_area').style.display='none';$('relation_product_area').style.display='none';\" onFocus='this.blur();' align='absmiddle' value=4 ".($use_product_type == 4 ? "checked":"")."><label class='blue' for='use_product_type_4'>특정 브랜드에 속한 상품에 발급합니다.</label><br>
			  	<div class='doong' id='relation_brand_area' style='".($use_product_type == 4 ? "display:block;":"display:none;")."vertical-align:top;height:30px;'   >";
			  	
if($use_product_type == 4){
		$sql = "Select crb.b_ix from mallstory_cupon_relation_brand crb
						where publish_ix = '".$publish_ix."' ";	
		$db->query($sql);
		$db->fetch();
		$brand = $db->dt[b_ix];
}
$Contents .= "
			  	<table cellpadding=3>
			  			<tr>
				  			<td  nowrap><img src='../image/ico_dot.gif' align=absmiddle> <b>브랜드 선택 </b>&nbsp;&nbsp; </td>
				  			<td>".BrandListSelect($brand, $cid)."</td>
			  			</tr>
			  		</table>
			  	</div>
			  	<input type='radio' name='use_product_type' id='use_product_type_2' onclick=\"$('relation_brand_area').style.display='none';$('relation_category_area').style.display='block';$('relation_product_area').style.display='none';\" onFocus='this.blur();' align='absmiddle' value=2 ".($use_product_type == 2 ? "checked":"")."><label class='blue' for='use_product_type_2'>카테고리에 등록된 상품에 발급합니다(선택한 카테고리 하부 상품에 모두 적용됩니다.)</label><br>
			  	
					<div class='doong' id='relation_category_area' style='".($use_product_type == 2 ? "display:block;":"display:none;")."vertical-align:top;height:60px;'   >
					<table border=0 cellpadding=0 cellspacing=0 style='margin-top:10px;'>
						<tr bgcolor='#ffffff'>
							<td  nowrap><img src='../image/ico_dot.gif' align=absmiddle> <b>카테고리 선택 </b>&nbsp;&nbsp; </td>
							<td  >
							<input type='hidden' name='selected_cid' value=''>
							<input type='hidden' name='selected_depth' value=''>
							<input type='hidden' id='_category'>	
													
								<table border=0 cellpadding=0 cellspacing=0>
									<tr>
										<td style='padding-right:5px;'>".getCategoryList("대분류", "cid0", "cid","onChange=\"loadCategory(this,'cid1',2)\" title='대분류' ", 0, $cid)." </td>	
										<td style='padding-right:5px;'>".getCategoryList("중분류", "cid1",  "cid","onChange=\"loadCategory(this,'cid2',2)\" title='중분류'", 1, $cid)." </td>
										<td style='padding-right:5px;'>".getCategoryList("소분류", "cid2", "cid", "onChange=\"loadCategory(this,'cid3',2)\" title='소분류'", 2, $cid)." </td>
										<td>".getCategoryList("세분류", "cid3", "cid", "onChange=\"loadCategory(this,'cid_1',2)\" title='세분류'", 3, $cid)."</td>
										<td style='padding-left:10px'><img src='../image/btc_add.gif' align=absmiddle border=0 onclick=\"categoryadd()\"></td>
									</tr>
								</table>";
								
						$Contents .= "	</td>
						</tr>
					</table><br>
					<table width=100% cellpadding=0 cellspacing=0 id=objCategory>
						<col width=1>
						<col width=50>
						<col width=545>
						<col>";
if($use_product_type == 2){
		$sql = "Select crc.cid from mallstory_cupon_relation_category crc, mallstory_category_info c 
						where c.cid = crc.cid and publish_ix = '".$publish_ix."' 
						order by crc.cpc_ix asc";	
		$db->query($sql);
		
		for($j=0;$j < $db->total;$j++){
			$db->fetch($j);
			$Contents  .= "<tr height=23><td><input type=text name=category[] id='_category' value='".$db->dt[cid]."' style='display:none'><input type=text name=depth[] value='".$db->dt[depth]."' style='display:none'></td><td></td><td>".getCategoryPathByAdmin($db->dt[cid], 4)."</td><td><a href='javascript:void(0)' onClick='category_del(this.parentNode.parentNode)'><img src='../images/i_close.gif' border=0></a></td></tr>";
		}
}
$Contents .= "</table><br><br>
					</div>
					<input type='radio' name='use_product_type' id='use_product_type_3' onclick=\"$('relation_category_area').style.display='none';$('relation_product_area').style.display='block';\" onFocus='this.blur();' align='absmiddle' value=3 ".($use_product_type == 3 ? "checked":"")."><label class='blue' for='use_product_type_3'>특정 상품에 발급합니다 (트리에서 상품을 검색후 Drag & Drop 을 통해서 등록합니다)</label><br>
					
			  	<!-- 카테고리 및 상품 검색 인터페이스 -->
					<div class='doong' id='relation_product_area' style='".($use_product_type == 3 ? "display:block;":"display:none;")."vertical-align:top;height:260px;'   >
					<table bgcolor=#ffffff border=0 cellpadding=0 cellspacing=0 width=100%' style='margin-top:10px;'>
					<tr height=25 >
						<td width='15%' style='padding-right:5px;' valign=top>
							<div class='tab' style='margin: 0px 0px ;'>
								<table class='s_org_tab'>
								<tr>
									<td class='tab'>
										<table id='tab_01' class='on' >
										<tr>
											<th class='box_01'></th>
											<td class='box_02 small' onclick=\"showTabContents('category_search','tab_01')\" style='padding-left:5px;padding-right:5px;'>카테고리검색</td>
											<th class='box_03'></th>
										</tr>
										</table>
										<table id='tab_02'>
										<tr>
											<th class='box_01'></th>
											<td class='box_02 small' onclick=\"showTabContents('keyword_search','tab_02')\" style='padding-left:5px;padding-right:5px;'>키워드검색</td>
											<th class='box_03'></th>
										</tr>
										</table>
										
									</td>
									<td class='btn'>						
										
									</td>
								</tr>
								</table>	
							</div>
							<div class='t_no' style='margin: 2px 0px ; '>
								<div class='my_box' >
									<div id='category_search' style='overflow:auto;height:370px;width:200px;border:1px solid silver'><iframe  src='relationAjax.category.php' width=100% height=100% frameborder=0 ></iframe></div>
									<div id='keyword_search' style='display:none;height:370px;width:200px;border:1px solid silver;padding-top:10px;'>
										
										<table align=center>
											<tr>
												<td bgcolor='#efefef' align=center>입점업체</td>
												<td>
													".CompanyList($company_id,"","")."
												</td>
											</tr>
											<tr>
												<td>
													<select name='search_type' id='search_type'>
														<option value='p.pname'>상품명</option>
														<option value='p.pcode'>상품코드</option>
														<option value='p.brand_name'>브랜드명</option>
														
													</select>
												</td>
												<td><input type='text' name='search_text' id='search_text' size='15' onkeydown=\"if(event.keyCode == 13){SearchProduct(document.form_cupon);return false;};\"></td>
											</tr>
											<tr>												
												<td colspan=2 align=right><img src='../image/search01.gif' onclick=\"SearchProduct(document.form_cupon);\"></td>
											</tr>											
											</table>
											
									</div>								
								</div>
							</div>
							</td>
						<td colspan=2 width='100%' valign=top>						
						<table border=0 cellpadding=0 cellspacing=0 width=100% height=100% >
							<tr height=25>
								<td style='padding:1px;padding-left:10px;padding-right:10px;border:1px solid silver;border-bottom:0px;' align=center >
								<table width=100% height=100%><tr><td align=left width='10' ><input type=hidden id='cpid' value=''><input type=checkbox name='all_fix' onclick='fixAll(document.form_cupon)' ></td><td id='view_paging' align=center></td></tr></table>
								</td>
								<td style='padding:0 0 0 5' rowspan=3></td>
							</tr>
							<tr height=92%>
								<td width=50%>
								<div id='reg_product' style='width:100%;height:350px;width:100%;height:100%;padding:1px;padding-left:10px;padding-right:10px;border:1px solid silver;' align=center >
								<table width=100% height=100%><tr><td align=center class='small'>좌측카테고리를 선택해주세요</td></tr></table>
								</div><!--ondragstart='return false' onselectstart='return false' -->
								</td>
								<td width=50% style='padding:0 0 0 0'>
									<div id='drop_relation_product'  >
									".relationCouponProductList($publish_ix)."
									</div><!--ondragover=\"this.style.border='3px solid silver';\" ondragout=\"this.style.border='1px solid silver';\" dropzone='true' ondrop=\"onDropAction('insert','".$event_ix."',arguments[0].id);\" ondragstart='return false' onselectstart='return false' -->
								</td>
							</tr>
							<tr height=25>
								<td style='padding:1px;padding-left:0px;padding-right:2px;border:1px solid silver;border-top:0px;' align=center >
								<img src='../image/btn_selected_reg.gif' border='0' align='left' onclick='selectGoodsList(document.form_cupon);' style='cursor:hand;'>
								<!--img src='../image/btn_searched_reg.gif' border='0' align='right'-->
								<select name='list_max' id='list_max' align=right onchange='getRelationProduct(_mode,_nset, _page,_cid,_depth);'>
									<option value='3'>3</option>
									<option value='5' selected>5</option>
									<option value='10'>10</option>
									<option value='15'>15</option>
									<option value='20'>20</option>
									<option value='30'>30</option>
									<option value='40'>40</option>
									<option value='50'>50</option>
									<!--option value='100'>100</option-->
								</select>
								</td>
								
								<td style='padding:1px;padding-left:0px;padding-right:2px;border:1px solid silver;border-top:0px;'><img src='../image/btn_whole_del.gif' border='0' align='left' onclick='deleteWhole();' style='cursor:hand;'></td>
								</tr>
						</table>
						<!--/div-->
						</td>
					</tr>					
					</table>
					</div>
					<!-- 카테고리 및 상품 검색 인터페이스 -->
			  	</td>
			  </tr>
        <tr bgcolor='#FAFAFA'>
          <td bgcolor='white'>발급구분</td>
          <td style='line-height:120%'>
          <input type='radio' name='publish_type' id='publish_type_1' onFocus='this.blur();' align='middle' value=1 onclick='javascript:displaySub2(cupon_send_type_select); ' ".($publish_type == 1 ? "checked":"")."><label for='publish_type_1' class='green'>지정발급</label>&nbsp;
          <input type='radio' name='publish_type' id='publish_type_2' onFocus='this.blur();' align='middle' value=2 onclick='javascript:displaySub2(cupon_send_type_random); ' ".($publish_type == 2 ? "checked":"")."><label for='publish_type_2' class='green'>무작위발급</label><br><br>
          <span class=small>지정 발행의 경우 쿠폰 발행후에 사용자를 직접 등록 하시면 됩니다. </span>
          </td>
        </tr>
        <tr bgcolor='#FAFAFA' id='cupon_send_type_select' style='".($publish_type == 1 ? "display: block;":"display: none;")." width: 100%; filter: blendTrans(Duration=1.5)'>
	          <td  bgcolor='white' nowrap></td>
	          <td >
	          	
	          	<!--font class='yellow'>한명</font>&nbsp;<input type='text' id='fid' name='mem_id' value='$mem_id' class='input' maxlength='12' style='height: 20px; width: 150px; filter: blendTrans(duration=0.5)' onFocus=\"FIn(fid,'#FFD323',0)\" onFocusOut=\"FOut(fid,'',0)\" align='absmiddle'>
	          	<input type='hidden'  name='mem_ix' value='$mem_ix'>&nbsp;<a href=javascript:PoPWindow('../member.find.php?type=form_cupon','410','300','member_find');><img src='../image/btc_search.gif' border='0' align='absmiddle'></a-->
	          </td>
	  		</tr>
      </table>
    </td>
  </tr>
  
  <tr>
    <td valign='top'>
      <span id='cupon_send_type_random' style='display: none; width: 100%; filter: blendTrans(Duration=1.5)'>
      <table width='100%' border='0' cellpadding='0' cellspacing='0'>
        <tr>
          <td></td>
        </tr>
      </table>
      </span>
    </td>
  </tr>
  <tr>
    <td height='20'></td>
  </tr>  
  <tr>
    <td align='right'><!--a href='iframe_admin_send_cupon_list.php'--><input type=image src='../image/b_save.gif' border='0'><!--/a--></td>
  </tr>
</form>
</table>
  ";

$help_text = "
<table cellpadding=0 cellspacing=0 class='small' >
	<col width=8>
	<col width=*>
	<tr><td ><img src='/admin/image/icon_list.gif' ></td><td class='small' >생성된 쿠폰을 발행 하는 단계 입니다.</td></tr>
	<tr><td valign=top><img src='/admin/image/icon_list.gif' ></td><td class='small' >쿠폰은 전체상품 발행 쿠폰, 카테고리별 상품 발행 쿠폰, 상품별 발행쿠폰 세가지 종류의 쿠폰이 있습니다.</td></tr>
	<tr><td valign=top><img src='/admin/image/icon_list.gif' ></td><td class='small' >쿠폰 발급은 지정발급과 무작위 발급이 있습니다. 지정발급의 경우는 관리자가 직접 사용자를 등록 합니다. </td></tr>
	<tr><td valign=top><img src='/admin/image/icon_list.gif' ></td><td class='small' >쿠폰 발급후 사용기간 변경시 <u>기 발급된 사용자에 대한 사용기간은 변경되지 않습니다.</u> </td></tr>
</table>
";


$Contents .=  HelpBox("쿠폰 발행", $help_text);

if($mmode == "pop"){	
	
	$P = new ManagePopLayOut();
	$P->addScript = $Script;
	$P->OnloadFunction = "init();";
	$P->strLeftMenu = marketting_menu();
	$P->Navigation = "HOME > 마케팅지원 > 쿠폰발행관리";
	$P->NaviTitle = "쿠폰발행관리";
	$P->strContents = $Contents;
	echo $P->PrintLayOut();
}else{
	$P = new LayOut();
	$P->addScript = $Script;
	$P->OnloadFunction = "init();";
	$P->strLeftMenu = marketting_menu();
	$P->Navigation = "HOME > 마케팅지원 > 쿠폰발행관리";
	$P->strContents = $Contents;
	echo $P->PrintLayOut();
}


function SelectCuponKind($select_ix){	
	$mdb = new MySQL;
		
	$mdb->query("SELECT * FROM ".TBL_MALLSTORY_CUPON." order by cupon_ix asc");	
	$mstring =  "<select name='cupon_ix' id='cupon_ix' style=\"font-size:12px;height: 20px; width: 300px;\" align='middle'><!--behavior: url('../js/selectbox.htc'); -->";
			
       $mstring .=  "     <option value=''>ㆍ선택ㆍㆍㆍㆍㆍㆍㆍ</option>";
        	
    for($i=0;$i < $mdb->total;$i++){   
	 	$mdb->fetch($i);	 	
	 	if($select_ix == $mdb->dt[cupon_ix]){
	    	$mstring .= "       <option value='".$mdb->dt[cupon_ix]."' selected>ㆍ".$mdb->dt[cupon_kind]."</option>\n";    
		}else{
			$mstring .= "       <option value='".$mdb->dt[cupon_ix]."'>ㆍ".$mdb->dt[cupon_kind]."</option>\n";    	
		}
	}
    $mstring .= "</select>";
    
    return $mstring;
	
}


function relationCouponProductList($publish_ix){
	global $admin_config;
	$db = new MySQL;
	
	$sql = "Select crp.*, p.pname from ".TBL_MALLSTORY_PRODUCT." p, mallstory_cupon_relation_product crp where p.id = crp.pid and publish_ix = '".$publish_ix."' order by crp.vieworder asc ";	
	$db->query($sql);
	
	
 
	$mString .= "<table id=tb_relation_product cellpadding=0 cellspacing=0 class=tb>
								<col width=50>";
								
	for($i=0;$i<$db->total;$i++){
		$db->fetch($i);			
		
		$mString .= "
					<tr style='background: url(../images/dot.gif) repeat-x left bottom; ' height=27 bgcolor=#ffffff onclick=\"spoit(this)\" ondblclick=\"$('tb_relation_product').deleteRow(this.rowIndex);	\">
					<td class=table_td_white align=center style='padding:5px;'>
						<img src='".$admin_config[mall_data_root]."/images/product/c_".$db->dt[pid].".gif'>
					</td>						
					<td class=table_td_white>".cut_str($db->dt[pname],30)."</td>			
					<td class=table_td_white><input type='hidden' name='rpid[]' value='".$db->dt[pid]."'></td>					
					</tr>";
	}
	
	
	$mString .= "</table>";
	
	return $mString;
	
}

?>