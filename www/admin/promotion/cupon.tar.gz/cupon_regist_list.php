<?
include("../class/layout.class");

$db = new MySQL();
	
$db->query("Select * from ".TBL_MALLSTORY_CUPON." ");
$total = $db->total;

$Script ="<script language=javascript>
function DeleteCupon(cupon_ix){
	if(confirm('정말로 삭제하시겠습니까?')){
		document.location.href='cupon.act.php?act=delete&cupon_ix='+cupon_ix
	}	
}
</script>";


$Contents = "
<table width='100%' border='0' cellpadding='0' cellspacing='0'>  
  <tr>
    <td height='2'></td>
  </tr>
  <tr>
	<td align='left' colspan=6 style='padding:0 0 10 0;'> ".GetTitleNavigation("쿠폰목록", "마케팅지원 > 쿠폰목록 ")."</td>
  </tr>
  <tr>
	    <td align='left' colspan=4 style='padding-bottom:20px;'> 
	    	<div class='tab'>
					<table class='s_org_tab'>
					<tr>
						<td class='tab'>
							<table id='tab_01' >
							<tr>
								<th class='box_01'></th>
								<td class='box_02' onclick=\"document.location.href='cupon_publish.php'\" >쿠폰발행</td>
								<th class='box_03'></th>
							</tr>
							</table>
							<table id='tab_02' >
							<tr>
								<th class='box_01'></th>
								<td class='box_02' onclick=\"document.location.href='cupon_regist_modify.php'\">쿠폰생성</td>
								<th class='box_03'></th>
							</tr>
							</table>
							<table id='tab_03' class='on'>
							<tr>
								<th class='box_01'></th>
								<td class='box_02' onclick=\"document.location.href='cupon_publish_list.php'\">쿠폰목록</td>
								<th class='box_03'></th>
							</tr>
							</table>
						</td>
						<td style='width:600px;text-align:right;vertical-align:bottom;padding:0 0 10 0'>						
							총건수 :&nbsp;<b>".$total."</b>
						</td>
					</tr>
					</table>	
				</div>
	    </td>
	</tr>	
  <tr>
    <td height='3'></td>
  </tr>  
  <tr>
    <td valign='top'>
      <table width='100%' border='0' cellpadding='0' cellspacing='0'>
        <tr>
          <td width='16'><!--img src='../icon/icon_dot5.gif' align='absmiddle'--></td>
          <td class='blue16'>전체 등록 쿠폰 수 :&nbsp;<b>".$total."</b>&nbsp;개</td>
          <td align=right></td>
        </tr>
      </table>
    </td>
  </tr>
  <tr>
    <td height='5'></td>
  </tr>";

if($db->total < 1){
	$Contents .= "<tr height=50><td colspan=20 align=center> 등록된 쿠폰 정보가 없습니다. </td></tr>";
}else{	
$max = 10;

if ($page == ''){
	$start = 0;
	$page  = 1;
}else{
	$start = ($page - 1) * $max;
}

$db->query("Select * from ".TBL_MALLSTORY_CUPON." order by regdate asc LIMIT $start, $max ");
	
	for($i=0;$i<$db->total;$i++){
		$db->fetch($i);	
		
		if(file_exists("$DOCUMENT_ROOT".$admin_config[mall_data_root]."/images/cupon/cupon_".$db->dt[cupon_ix].".gif")){
			$cupon_img = "<img src='".$admin_config[mall_data_root]."/images/cupon/cupon_".$db->dt[cupon_ix].".gif' border='0' width='140' height='92' name='previews'>";
		}else{
			$cupon_img = "";
		}
		
		$Contents .= "
		  <!--- // 목록 반복 시작 ---------->
		  <tr>
		    <td height='10'></td>
		  </tr>
		  <tr>
		    <td>
		      <table width='100%' border='0' cellpadding='15' cellspacing='0' style='border:1px solid #E9E9E9;' bgcolor=#FAFAFA>		        
		        <tr >		          
		          <td class='con_l'>
		            <table width='100%' border='0' cellpadding='20' cellspacing='1' bgcolor='#E9E9E9'>		            
		              <tr bgcolor='white'>
		                <td class='con_l' rowspan=2>".$cupon_img."</td>
		                <td class='con_l'> 
		                	<font class='green'><font size='3'><b><img src='../image/ico_dot.gif' border=0> 쿠폰종류 : ".$db->dt[cupon_kind]."</b></font></font><br>		                	
		                </td>
		              </tr>
		              <tr bgcolor='white'>
		              	<td align=right>
		              		<img src='../image/0.gif' width='1' height='10'><br><a href=\"javascript:DeleteCupon('".$db->dt[cupon_ix]."');\"><img src='../image/btc_del.gif' border='0' align='right'></a> 
		              		<a href='cupon_regist_modify.php?cupon_ix=".$db->dt[cupon_ix]."'><img src='../image/btc_modify.gif' border='0' align='right'></a>
		              	</td>
		              </tr>
		            </table>
		          </td>
		        </tr>
		      </table>
		    </td>
		  </tr>
		  <tr>
		    <td height='10'></td>
		  </tr>";
	}//for 
	
$Contents .= " 
	<tr>
    <td height='10'>
    <table width='100%' border='0' cellpadding='0' cellspacing='0'>
        <tr>
          <td align='center'>".page_bar($total, $page, $max,$HTTP_URL,'')."</td>
        </tr>
      </table>	
    </td>
  </tr>";

}

$Contents .= " 
</table>";



$P = new LayOut();
$P->addScript = $Script;
$P->strLeftMenu = marketting_menu();
$P->Navigation = "HOME > 마케팅지원 > 쿠폰관리";
$P->strContents = $Contents;
echo $P->PrintLayOut();

?>