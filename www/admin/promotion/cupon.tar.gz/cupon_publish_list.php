<?
include("../class/layout.class");

if ($FromYY == ""){
	$before10day = mktime(0, 0, 0, date("m")  , date("d")-20, date("Y"));
	
//	$sDate = date("Y/m/d");
	$sDate = date("Y/m/d", $before10day);
	$eDate = date("Y/m/d");
	
	$startDate = date("Ymd", $before10day);
	$endDate = date("Ymd");
}else{
	$sDate = $FromYY."/".$FromMM."/".$FromDD;
	$eDate = $ToYY."/".$ToMM."/".$ToDD;
	$startDate = $FromYY.$FromMM.$FromDD;
	$endDate = $ToYY.$ToMM.$ToDD;
}

$where = " where c.cupon_ix is not null ";

if($search_type != "" && $search_text != ""){	
	$where .= " and $search_type LIKE  '%$search_text%' ";
}
	
$startDate = $FromYY.$FromMM.$FromDD;
$endDate = $ToYY.$ToMM.$ToDD;
		
if($startDate != "" && $endDate != ""){	
	$where .= " and  cp.regdate between  $startDate and $endDate ";
}
	
$db = new MySQL();
$rproduct_db = new MySQL();

if($publish_type == ""){
	//$sql = "Select * from ".TBL_MALLSTORY_CUPON_PUBLISH." ";
	$sql = "select cp.*,c.cupon_kind 
					from ".TBL_MALLSTORY_CUPON."  c inner join ".TBL_MALLSTORY_CUPON_PUBLISH." cp on c.cupon_ix = cp.cupon_ix 
					$where order by cp.regdate desc";
}else{
	//$sql = "Select * from ".TBL_MALLSTORY_CUPON_PUBLISH." where publish_type ='$publish_type' ";
	$sql = "select cp.*,c.cupon_kind 
					from ".TBL_MALLSTORY_CUPON."  c inner join ".TBL_MALLSTORY_CUPON_PUBLISH." cp on c.cupon_ix = cp.cupon_ix 
					$where and publish_type ='$publish_type' order by cp.regdate desc";
}

$db->query($sql);
$total = $db->total;
$Script = "
<script language='javascript' src='../include/DateSelect.js'></script>
<script language='javascript'>
	function publish_delete(publish_ix){
		if(confirm('정말 쿠폰발행을 삭제 하시겠습니까?')){
			document.frames['act'].location.href='cupon.act.php?act=publish_delete&publish_ix='+publish_ix;
		}
	}
	
	
function init_date(FromDate,ToDate) {
	var frm = document.search_coupon;
	
	
	for(i=0; i<frm.FromYY.length; i++) {
		if(frm.FromYY.options[i].value == FromDate.substring(0,4))
			frm.FromYY.options[i].selected=true
	}
	for(i=0; i<frm.FromMM.length; i++) {
		if(frm.FromMM.options[i].value == FromDate.substring(5,7))
			frm.FromMM.options[i].selected=true
	}
	for(i=0; i<frm.FromDD.length; i++) {
		if(frm.FromDD.options[i].value == FromDate.substring(8,10))
			frm.FromDD.options[i].selected=true
	}
	
	
	for(i=0; i<frm.ToYY.length; i++) {
		if(frm.ToYY.options[i].value == ToDate.substring(0,4))
			frm.ToYY.options[i].selected=true
	}
	for(i=0; i<frm.ToMM.length; i++) {
		if(frm.ToMM.options[i].value == ToDate.substring(5,7))
			frm.ToMM.options[i].selected=true
	}
	for(i=0; i<frm.ToDD.length; i++) {
		if(frm.ToDD.options[i].value == ToDate.substring(8,10))
			frm.ToDD.options[i].selected=true
	}
	
}


function onLoad(FromDate, ToDate) {
		var frm = document.search_coupon;
	
	
	LoadValues(frm.FromYY, frm.FromMM, frm.FromDD, FromDate);
	LoadValues(frm.ToYY, frm.ToMM, frm.ToDD, ToDate);
	
	frm.FromYY.disabled = true;
	frm.FromMM.disabled = true;
	frm.FromDD.disabled = true;
	frm.ToYY.disabled = true;
	frm.ToMM.disabled = true;
	frm.ToDD.disabled = true;	
	
	init_date(FromDate,ToDate);
	
}

function ChangeRegistDate(frm){
	if(frm.regdate.checked){
		frm.FromYY.disabled = false;
		frm.FromMM.disabled = false;
		frm.FromDD.disabled = false;
		frm.ToYY.disabled = false;
		frm.ToMM.disabled = false;
		frm.ToDD.disabled = false;
	}else{
		frm.FromYY.disabled = true;
		frm.FromMM.disabled = true;
		frm.FromDD.disabled = true;
		frm.ToYY.disabled = true;
		frm.ToMM.disabled = true;
		frm.ToDD.disabled = true;		
	}
}


function select_date(FromDate,ToDate,dType) {
	var frm = document.search_coupon;
	
	if(dType == 1){
		for(i=0; i<frm.FromYY.length; i++) {
			if(frm.FromYY.options[i].value == FromDate.substring(0,4))
				frm.FromYY.options[i].selected=true
		}
		for(i=0; i<frm.FromMM.length; i++) {
			if(frm.FromMM.options[i].value == FromDate.substring(5,7))
				frm.FromMM.options[i].selected=true
		}
		for(i=0; i<frm.FromDD.length; i++) {
			if(frm.FromDD.options[i].value == FromDate.substring(8,10))
				frm.FromDD.options[i].selected=true
		}
		
		
		for(i=0; i<frm.ToYY.length; i++) {
			if(frm.ToYY.options[i].value == ToDate.substring(0,4))
				frm.ToYY.options[i].selected=true
		}
		for(i=0; i<frm.ToMM.length; i++) {
			if(frm.ToMM.options[i].value == ToDate.substring(5,7))
				frm.ToMM.options[i].selected=true
		}
		for(i=0; i<frm.ToDD.length; i++) {
			if(frm.ToDD.options[i].value == ToDate.substring(8,10))
				frm.ToDD.options[i].selected=true
		}
	}
	
}



</script>";

$vdate = date("Ymd", time());
$today = date("Y/m/d", time());
$vyesterday = date("Y/m/d", time()-84600);
$voneweekago = date("Y/m/d", time()-84600*7);
$vtwoweekago = date("Y/m/d", time()-84600*14);
$vfourweekago = date("Y/m/d", time()-84600*28);
$vyesterday = date("Y/m/d",mktime(0,0,0,substr($vdate,4,2),substr($vdate,6,2),substr($vdate,0,4))-60*60*24);
$voneweekago = date("Y/m/d",mktime(0,0,0,substr($vdate,4,2),substr($vdate,6,2),substr($vdate,0,4))-60*60*24*7);
$v15ago = date("Y/m/d",mktime(0,0,0,substr($vdate,4,2),substr($vdate,6,2),substr($vdate,0,4))-60*60*24*15);
$vfourweekago = date("Y/m/d",mktime(0,0,0,substr($vdate,4,2),substr($vdate,6,2),substr($vdate,0,4))-60*60*24*28);
$vonemonthago = date("Y/m/d",mktime(0,0,0,substr($vdate,4,2)-1,substr($vdate,6,2)+1,substr($vdate,0,4)));
$v2monthago = date("Y/m/d",mktime(0,0,0,substr($vdate,4,2)-2,substr($vdate,6,2)+1,substr($vdate,0,4)));
$v3monthago = date("Y/m/d",mktime(0,0,0,substr($vdate,4,2)-3,substr($vdate,6,2)+1,substr($vdate,0,4)));	

$Contents = "
<table width='100%' border='0' cellpadding='0' cellspacing='0'>
  <tr>
		<td align='left' colspan=6 style='padding:0 0 10 0;'> ".GetTitleNavigation("쿠폰 발행 리스트", "마케팅지원 > 쿠폰 발행 리스트 ")."</td>
  </tr>
  <tr>
	    <td align='left' colspan=4 style='padding-bottom:20px;'> 
	    	<div class='tab'>
					<table class='s_org_tab'>
					<tr>
						<td class='tab'>
							<table id='tab_01' >
							<tr>
								<th class='box_01'></th>
								<td class='box_02' onclick=\"document.location.href='cupon_publish.php'\" >쿠폰발행</td>
								<th class='box_03'></th>
							</tr>
							</table>
							<table id='tab_02' class='on'>
							<tr>
								<th class='box_01'></th>
								<td class='box_02' onclick=\"document.location.href='cupon_publish_list.php'\">쿠폰발행 목록</td>
								<th class='box_03'></th>
							</tr>
							</table>
							
						</td>
						<td style='width:700px;text-align:right;vertical-align:bottom;padding:0 0 10 0'>						
							총건수 :&nbsp;<b>".$total."</b>
						</td>
					</tr>
					</table>	
				</div>
	    </td>
	</tr>
	<tr>
    <td colspan=7>
        <form name='search_coupon'>
        <table border='0' cellpadding='0' cellspacing='0' width='100%'>
            <tr>
                <td style='width:100%;' valign=top colspan=3>
                    <table width=100%  border=0>
                        <tr height=25>
                            <td style='border-bottom:2px solid #efefef'><img src='../images/dot_org.gif' align=absmiddle> <b>쿠폰 발행 목록 검색하기</b></td>
                        </tr>
                        <tr>
                            <td align='left' colspan=2 height=50 width='100%' valign=top style='padding-top:5px;'>
                                <table class='box_shadow' style='width:100%;' align=left>
                                    <tr>
                                        <th class='box_01'></th>
                                        <td class='box_02'></td>
                                        <th class='box_03'></th>
                                    </tr>
                                    <tr>
                                        <th class='box_04'></th>
                                        <td class='box_05' valign=top>
                                            <TABLE height=20 cellSpacing=0 cellPadding=10 style='width:100%;' align=center border=0>
                                                <TR>
                                                    <TD bgColor=#ffffff style='padding:0 0 0 0;height:30px;'>
                                                        <table cellpadding=2 cellspacing=1 width='100%'>

                                                            <tr>
                                                                <th bgcolor='#efefef' width='150'>조건검색 : </th>
                                                                <td colspan=2>
                                                                    <table>
                                                                        <tr>
                                                                            <td>
                                                                                <select name=search_type>
                                                                                <option value='cupon_no' ".CompareReturnValue("cupon_no",$search_type,"selected").">쿠폰번호</option>

                                                                                </select>
                                                                            </td>
                                                                            <td><input type=text class=textbox name='search_text' value='".$search_text."' style='width:200px;' ></td>
                                                                        </tr>

                                                                    </table>
                                                                </td>
                                                            </tr>
                                                            <tr height=30>
                                                                <th bgcolor='#efefef'><img src='../image/ico_dot.gif' align='absmiddle'>발행형태</th>
                                                                <td align='left' class='gray16'>
                                                                    <input type='radio' name='publish_type' id='publish_type_1' onFocus='this.blur();' align='middle' value='' ".CompareReturnValue($publish_type,'',' checked')."><label for='publish_type_1'>모두보기</label>&nbsp;
                                                                    <input type='radio' name='publish_type' id='publish_type_2' onFocus='this.blur();' align='middle' value=1 ".CompareReturnValue($publish_type,'1',' checked')."><label for='publish_type_2'>지정발행보기</label>&nbsp;
                                                                    <input type='radio' name='publish_type' id='publish_type_3' onFocus='this.blur();' align='middle' value=2 ".CompareReturnValue($publish_type,'2',' checked')."><label for='publish_type_3'>무작위발행보기</label>
                                                                </td>
                                                            </tr>
                                                            <tr height=1><td colspan=4 class='dot-x'></td></tr>
                                                            <tr height=27>
                                                                <td bgcolor='#efefef' align=center><label for='regdate'><b>발행일자</b></label><input type='checkbox' name='regdate' id='regdate' value='1' onclick='ChangeRegistDate(document.search_coupon);'></td>
                                                                <td align=left colspan=3 style='padding-left:5px;'>
                                                                    <table cellpadding=0 cellspacing=2 border=0 bgcolor=#ffffff>
                                                                        <tr>
                                                                            <TD width=200 nowrap><SELECT onchange=javascript:onChangeDate(this.form.FromYY,this.form.FromMM,this.form.FromDD) name=FromYY ></SELECT> 년 <SELECT onchange=javascript:onChangeDate(this.form.FromYY,this.form.FromMM,this.form.FromDD) name=FromMM></SELECT> 월 <SELECT name=FromDD></SELECT> 일 </TD>
                                                                            <TD width=20 align=center> ~ </TD>
                                                                            <TD width=200 nowrap><SELECT onchange=javascript:onChangeDate(this.form.ToYY,this.form.ToMM,this.form.ToDD) name=ToYY></SELECT> 년 <SELECT onchange=javascript:onChangeDate(this.form.ToYY,this.form.ToMM,this.form.ToDD) name=ToMM></SELECT> 월 <SELECT name=ToDD></SELECT> 일</TD>
                                                                            <TD>
                                                                                <a href=\"javascript:select_date('$voneweekago','$today',1);\"><img src='../image/b_btn_s_1week01.gif'></a>
                                                                                <a href=\"javascript:select_date('$v15ago','$today',1);\"><img src='../image/b_btn_s_15day01.gif'></a>
                                                                                <a href=\"javascript:select_date('$vonemonthago','$today',1);\"><img src='../image/b_btn_s_1month01.gif'></a>
                                                                                <a href=\"javascript:select_date('$v2monthago','$today',1);\"><img src='../image/b_btn_s_2month01.gif'></a>
                                                                                <a href=\"javascript:select_date('$v3monthago','$today',1);\"><img src='../image/b_btn_s_3month01.gif'></a>
                                                                            </TD>
                                                                        </tr>
                                                                    </table>
                                                                </TD>
                                                            </TR>

                                                        </table>
                                                    </TD>
                                                </TR>

                                            </TABLE>
                                        </td>
                                        <th class='box_06'></th>
                                    </tr>
                                    <tr>
                                        <th class='box_07'></th>
                                        <td class='box_08'></td>
                                        <th class='box_09'></th>
                                    </tr>
                                </table>

                            </td>
                        </tr>
                        <tr >
                            <td colspan=3 align=center  style='padding:10 0 0 0'>
                                <input type='image' src='../image/bt_search.gif' border=0>
                            </td>
                        </tr>
                    </table>
                </td>
            </tr>
        </table>
        </form>
    </td>
</tr>


  <tr>
    <td height='5'> 쿠폰 총 발행 수 :&nbsp;<b>".$total."</b>&nbsp;건 </td>
  </tr>
  <tr>
    <td height='10'></td>
  </tr>
  <tr>
    <td valign='top'>
      <table width='100%' border='0' cellpadding='0' cellspacing='0'>
        <tr>
          <td valign='top'>
            <table width='100%' border='0' cellpadding='10' cellspacing='1' bgcolor='#E9E9E9'>
              <tr>
                <td colspan='7' width='100%' height='3' ></td>
              </tr>
              <tr bgcolor='#FAFAFA' align=center>                
                <td class='con_c' bgcolor='white' nowrap>번호</td>
                <td class='con_c' bgcolor='white' nowrap>발행일자</td>
                <td class='con_c' bgcolor='white' nowrap>쿠폰번호/쿠폰내용</td>
                <td width='40%' class='con_c' bgcolor='white' nowrap>아이디/이름</td>
                <td class='con_c' bgcolor='white' nowrap>수령</td>
                <td class='con_c' bgcolor='white' nowrap>사용</td>
              </tr>";
              
if($db->total < 1){
	$Contents .= "<tr bgcolor=#ffffff height=50><td colspan=20 align=center> 등록된 쿠폰 정보가 없습니다. </td></tr>";
}else{	
$max = 10;

if ($page == ''){
	$start = 0;
	$page  = 1;
}else{
	$start = ($page - 1) * $max;
}

if($publish_type == ""){
	/*
	$sql = "SELECT cp.*, c.cupon_kind, m.name as mem_name, m.id as mem_id , cr.open_yn, cr.use_yn
			FROM ".TBL_MALLSTORY_CUPON_PUBLISH." cp left outer join ".TBL_MALLSTORY_CUPON_REGIST." cr on cr.publish_ix = cp.publish_ix left outer join  ".TBL_MALLSTORY_MEMBER." m on m.code = cr.mem_ix , ".TBL_MALLSTORY_CUPON." c
			where c.cupon_ix = cp.cupon_ix order by regdate desc LIMIT $start, $max ";
	*/
	$sql = "select cp.*,c.cupon_kind from ".TBL_MALLSTORY_CUPON."  c , ".TBL_MALLSTORY_CUPON_PUBLISH." cp 
					$where and c.cupon_ix = cp.cupon_ix order by cp.regdate desc LIMIT $start, $max";
	
}else{
	/*
		$sql = "SELECT cp.*, c.cupon_kind, m.name as mem_name, m.id as mem_id , cr.open_yn, cr.use_yn
			FROM ".TBL_MALLSTORY_CUPON_PUBLISH." cp left outer join ".TBL_MALLSTORY_CUPON_REGIST." cr on cr.publish_ix = cp.publish_ix left outer join  ".TBL_MALLSTORY_MEMBER." m on m.code = cr.mem_ix , ".TBL_MALLSTORY_CUPON." c
			where c.cupon_ix = cp.cupon_ix and publish_type ='$publish_type'  order by regdate desc LIMIT $start, $max ";
	*/
	$sql = "select cp.*,c.cupon_kind from ".TBL_MALLSTORY_CUPON."  c , ".TBL_MALLSTORY_CUPON_PUBLISH." cp
					$where and  c.cupon_ix = cp.cupon_ix and publish_type ='$publish_type' 
					order by cp.regdate desc LIMIT $start, $max";
	
}

//echo $sql;
$db->query($sql);
	
for($i=0;$i<$db->total;$i++){
	$db->fetch($i);	
	$no = $total - ($page - 1) * $max - $i;


	if($db->dt[use_date_type] == 1){
		if($db->dt[publish_date_type] == 1){
			$date_type = '년';			
		}else if($db->dt[publish_date_type] == 2){
			$date_type = '개월';
		}else if($db->dt[publish_date_type] == 3){
			$date_type = '일';
		}
		$date_differ = $db->dt[publish_date_differ];
		$use_date_type = '발행일';		
		$priod_str = $use_date_type."로부터 ".$date_differ." ".$date_type."간";
		
	}else if($db->dt[use_date_type] == 2){
		if($db->dt[regist_date_type] == 1){
			$date_type = '년';			
		}else if($db->dt[regist_date_type] == 2){
			$date_type = '개월';
		}else if($db->dt[regist_date_type] == 3){
			$date_type = '일';
		}
		$date_differ = $db->dt[regist_date_differ];
		$use_date_type = '등록일';
		$priod_str = $use_date_type."로부터 ".$date_differ." ".$date_type."간";
	}else if($db->dt[use_date_type] == 3){
		$use_date_type = '사용기간';
		$priod_str = $use_date_type." : ".ChangeDate($db->dt[use_sdate],"Y-m-d")." ~ ".ChangeDate($db->dt[use_edate],"Y-m-d")." ";
	}
		
	if($db->dt[use_product_type] == 3){		
		
		$sql = "Select crp.pid, p.pname from mallstory_cupon_relation_product crp, mallstory_product p where p.id = crp.pid and publish_ix = '".$db->dt[publish_ix]."' order by crp.vieworder asc";	
		$rproduct_db->query($sql);
		
		for($j=0;$j < $rproduct_db->total;$j++){
			$rproduct_db->fetch($j);
			$rproduct_str .= "<img src='".$admin_config[mall_data_root]."/images/product/c_".$rproduct_db->dt[pid].".gif' alt='".$rproduct_db->dt[pname]."' style='border:1px solid silver'> ";
		}
	}else if($db->dt[use_product_type] == 2){	
		$sql = "Select crc.cid from mallstory_cupon_relation_category crc, mallstory_category_info c 
						where c.cid = crc.cid and publish_ix = '".$db->dt[publish_ix]."' 
						order by crc.cpc_ix asc";	
		$rproduct_db->query($sql);
		
		for($j=0;$j < $rproduct_db->total;$j++){
			$rproduct_db->fetch($j);
			$rproduct_str .= "<b>".getCategoryPathByAdmin($rproduct_db->dt[cid], 4)."</b> &nbsp;&nbsp;&nbsp;<span class=small>카테고리 등록상품</span> <br> ";
		}
		
		//$rproduct_str .= "<b>선택된 카테고리</b>";
	}else if($db->dt[use_product_type] == 4){	
		$sql = "Select brand_name from mallstory_cupon_relation_brand crb, mallstory_brand b 
						where crb.b_ix = b.b_ix and crb.publish_ix = '".$db->dt[publish_ix]."' 
						";	
		//echo $sql;
		$rproduct_db->query($sql);
		
		if($rproduct_db->total){
			$rproduct_db->fetch();
			$rproduct_str = "<b>".$rproduct_db->dt[brand_name]." </b> 브랜드 상품";
		}
		
	}else{
		$rproduct_str = "<b>전체 상품</b>";
	}
	
	if ($db->dt[publish_type] == 1){
	
		$Contents .= "
              <!--- // 목록 반복 시작 ---------->
              <!--- / 지정발행일경우 - 쿠폰발행일자 - ()안은 유효기간, blue=사용날짜 ---------->
        	<tr bgcolor='#ffffff'>                
                <td rowspan='2' class='con_c' align=center nowrap>".$no."</td>
                <td class='con_c' nowrap><font class='gray16'>".$db->dt[regdate] ."</font><br><!--font class='td16'>(2006-04-01)</font><br><font class='blue16'>2006-03-20</font--></td>
                <td class='con_c' style='line-height:120%' nowrap><font class='yellow'>".$db->dt[cupon_kind] ."<br><a href='cupon_publish.php?publish_ix=".$db->dt[publish_ix] ."' class=blue>".$db->dt[cupon_no] ."</a></font></td>
                <td class='con_c' style='line-height:120%'>
                	<font class='green'><b>지정 발행</b> <span class='small'>(관리자가 사용자를 직접 지정합니다)</span></font><br>
                <a href=\"javascript:PopSWindow('cupon_register_user.php?publish_ix=".$db->dt[publish_ix]."',850,800,'cupon_detail_pop');\" class=blue>쿠폰발급(사용자등록)</a>
                </td>
                <td class='con_c' align=center nowrap><img src='../image/icon_".($db->dt[open_yn] == "1" ? "o":"x").".gif' border='0'></td>
                <td class='con_c' align=center nowrap><img src='../image/icon_".($db->dt[use_yn] == "1" ? "o":"x").".gif' border='0'></td>
              </tr>
        	<tr bgcolor='#ffffff'>
                <td colspan='3' class='con_l'>
	                <table>
		                <tr><td>유효기간 : </td><td>".$priod_str."&nbsp;&nbsp;(결제가격이 ".number_format($db->dt[publish_condition_price],0)." 원 이상인 상품에 사용가능)</td></tr>
		                <tr><td>사용가능상품 : </td><td style='padding:5px;line-height:120%'>".$rproduct_str." </td></tr>
	                </table>
                </td>
                <td colspan='2' align='center'>
                
                <a href='javascript:publish_delete(".intval($db->dt[publish_ix]).");'><img src='../image/btc_del.gif'></a></td>
              </tr>
              <!--- 지정발행일경우 / ---------->";
	}else{
		$Contents .= "
              <!--- / 무작위발행일경우 - 쿠폰발행일자 - ()안은 유효기간 ---------->
        	<tr bgcolor='#ffffff'>
                <td rowspan='2' class='con_c' align=center  nowrap>".$no."</td>
                <td class='con_c' nowrap><font class='gray16'>".$db->dt[regdate] ."</font><!--br><font class='td16'>(2006-04-01)</font--></td>
                <td class='con_c' nowrap><font class='yellow'>".$db->dt[cupon_kind] ."<br><a href='cupon_publish.php?publish_ix=".$db->dt[publish_ix] ."' class=blue>".$db->dt[cupon_no] ."</a></font></td>                
                <td class='con_c' style='line-height:120%'>
                <font class='orange'><b>무작위발행</b> <span class='small'>(사용자들이 쿠폰을 직접 등록할 수 있습니다.)</span></font><br>
                <a href=\"javascript:PopSWindow('cupon_register_user.php?publish_ix=".$db->dt[publish_ix]."',850,800,'cupon_detail_pop');\" class=blue>쿠폰발급(사용자등록)</a>
                </td>
                <td colspan='2' class='con_c' nowrap>
                	<!--a href='iframe_admin_random_send_cupon_list.php?publish_ix=".$db->dt[publish_ix] ."'>[목록보기]</a><br>
                	<img src='../img/0.gif' width='1' height='5'><br><a href='iframe_admin_random_send_cupon.php?publish_ix=".$db->dt[publish_ix] ."'>[쿠폰보내기]</a-->
                </td>
              </tr>
              <tr bgcolor='#ffffff'>
                <td colspan='3' class='con_l'>
                	<table>
		                <tr><td>유효기간 : </td><td>".$priod_str."&nbsp;&nbsp;(결제가격이 ".number_format($db->dt[publish_condition_price],0)." 원 이상인 상품에 사용가능)</td></tr>
		                <tr><td>사용가능상품 : </td><td style='padding:5px;'>".$rproduct_str." </td></tr>
	                </table>               
                </td>
                <td colspan='2' align='center'>                
								<!--a href=\"javascript:PoPWindow('cupon_register_user.php?publish_ix=".$db->dt[publish_ix]."',820,500,'cupon_detail_pop');\">발급현황</a--><br>
								<a href='javascript:publish_delete(".intval($db->dt[publish_ix]).");'><img src='../image/btc_del.gif'></a>
								</td>
              </tr>
              <!--- 무작위발행일경우 / ---------->";

	}
$rproduct_str='';
}//for 
$Contents .= "
							<tr bgcolor=#ffffff>
						    <td align='center' colspan=6 >".page_bar($total, $page, $max,$HTTP_URL,'')."</td>
						  </tr>";
}
$Contents .= "

              <!--- 목록 반복 끝 // ---------->

            </table>
          </td>
        </tr>
      </table>
    </td>
  </tr>
  <tr>
    <td height='20' valign='top'></td>
  </tr>
  
</table>";



$P = new LayOut();
$P->addScript = $Script;
$P->OnloadFunction = "onLoad('$sDate','$eDate', document.search_coupon);";//MenuHidden(false);
//$P->OnloadFunction = "init();";
$P->strLeftMenu = marketting_menu();
$P->Navigation = "HOME > 마케팅지원 > 쿠폰관리";
$P->strContents = $Contents;
echo $P->PrintLayOut();

?>
