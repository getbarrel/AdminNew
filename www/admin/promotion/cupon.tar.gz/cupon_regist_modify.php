<?
include("../class/layout.class");
//include("$DOCUMENT_ROOT../include/admin.util.php");
//include("$DOCUMENT_ROOT/class/mysql.class");

$db = new MySQL();
	
$db->query("Select * from ".TBL_MALLSTORY_CUPON." where cupon_ix ='$cupon_ix'");
$db->fetch();
//$total = $db->total;
if($db->total){
	$cupon_ix = $db->dt[cupon_ix];	
	$cupon_kind = $db->dt[cupon_kind];	
	$cupon_sale_value = $db->dt[cupon_sale_value];	
	$cupon_sale_type = $db->dt[cupon_sale_type];	
	$cupon_img = "<img src='".$admin_config[mall_data_root]."/images/cupon/cupon_".$db->dt[cupon_ix].".gif' border='1' style='border-color: #A5A5A5' name='preview_cupon'  id='preview_cupon' width='350' height='230' align='absmiddle'>";
	$act = "update";
}else{
	$cupon_ix = "";	
	$cupon_kind = "";
	$cupon_sale_value = "";
	$cupon_sale_type = "1";	
	$cupon_img = "<img src='../image/0.gif'  style='border:1px solid silver' name='preview_cupon' id='preview_cupon' width='350' height='230' align='absmiddle'>";
	$act = "insert";
}

$Contents = "
<table width='100%' border='0' cellpadding='0' cellspacing='0'>
  <!--- // 쿠폰등록 -------------------------------------------------------------------------> 
  <tr>
	<td align='left' colspan=6 style='padding:0 0 10 0;'> ".GetTitleNavigation("쿠폰 생성 / 수정", "마케팅지원 > 쿠폰 생성/수정 ")."</td>
  </tr>
  <tr>
	    <td align='left' colspan=4 style='padding-bottom:20px;'> 
	    	<div class='tab'>
					<table class='s_org_tab'>
					<tr>
						<td class='tab'>
							<table id='tab_01' >
							<tr>
								<th class='box_01'></th>
								<td class='box_02' onclick=\"document.location.href='cupon_publish.php'\" >쿠폰발행</td>
								<th class='box_03'></th>
							</tr>
							</table>
							<table id='tab_02' class='on'>
							<tr>
								<th class='box_01'></th>
								<td class='box_02' onclick=\"document.location.href='cupon_regist_modify.php'\">쿠폰생성</td>
								<th class='box_03'></th>
							</tr>
							</table>
							<table id='tab_03' >
							<tr>
								<th class='box_01'></th>
								<td class='box_02' onclick=\"document.location.href='cupon_regist_list.php'\">쿠폰목록</td>
								<th class='box_03'></th>
							</tr>
							</table>
						</td>
						<td style='width:600px;text-align:right;vertical-align:bottom;padding:0 0 10 0'>						
						
						</td>
					</tr>
					</table>	
				</div>
	    </td>
	</tr>	
  <tr>
    <td height='2'></td>
  </tr>  
  <tr>
    <td height='10'></td>
  </tr>  
  <tr>
    <td height='10'>쿠폰 생성/수정</font>&nbsp;(쿠폰종류, 쿠폰이미지 확인)</td>
  </tr>
  <tr>
    <td height='10'></td>
  </tr>
  <tr><form name='form_cupon' onsubmit='return CheckFormValue(this)' method='post' enctype='multipart/form-data'  action='cupon.act.php'>
  	<input type=hidden name='act' value='".$act."'>
  	<input type=hidden name='cupon_ix' value='".$cupon_ix."'>
    <td valign='top'>
      <table width='100%' border='0' cellpadding='0' cellspacing='0'>        
        <tr bgcolor='#FAFAFA' height=30>          
          <td class='con_l' bgcolor='white'><img src='../image/ico_dot.gif'> 쿠폰명</td>
          <td class='con_l'><input type='text' validation='true' title='쿠폰종류' id='fcupon_type' name='cupon_kind' class='input' maxlength='50' style='height: 20px; width: 300px; filter: blendTrans(duration=0.5)' align='absmiddle' value='".$cupon_kind."'></td>
        </tr>
        <tr><td colspan=2 class='dot-x'></td></tr>
        <tr bgcolor='#FAFAFA' height=30>          
          <td class='con_l' bgcolor='white'><img src='../image/ico_dot.gif'> 쿠폰종류</td>
          <td class='con_l'>
        		<input type=text class='input' validation='true' title='쿠폰종류' name='cupon_sale_value' id='cupon_sale_value' maxlength='20' style='height: 20px; width: 100px; filter: blendTrans(duration=0.5)'  align='absmiddle' value='".$cupon_sale_value."'> <input type=radio id='cupon_sale_type1' name='cupon_sale_type' value=1 ".CompareReturnValue('1', $cupon_sale_type, ' checked')."><label for='cupon_sale_type1'>%</label> <input type=radio id='cupon_sale_type2' name='cupon_sale_type' value=2 ".CompareReturnValue('2', $cupon_sale_type, ' checked')."><label for='cupon_sale_type2'>원</label>
          </td>
        </tr>
        <tr><td colspan=2 class='dot-x'></td></tr>
        <tr bgcolor='#FAFAFA' height=300>          
          <td class='con_l' bgcolor='white'><img src='../image/ico_dot.gif'> 쿠폰이미지</td>
          <td class='con_l'>".$cupon_img."<br><img src='../image/0.gif' width='1' height='10'><br><input type='file' validation='false' title='쿠폰이미지' id='fcupon_img' name='cupon_img' class='input' style='filter: blendTrans(duration=0.5); height: 20px; width: 418px' align='absmiddle' onchange='img_preview_cupon(this.value);'></td>
        </tr>
      </table>
    </td>
  </tr>
  <tr>
    <td height='20'></td>
  </tr>  
  <tr>
    <td align='right'><!--a href='iframe_admin_regist_cupon_list.php'--><input type=image src='../image/b_save.gif' border=0><!--/a--></td>
  </tr></form>
</table>";


$P = new LayOut();
$P->addScript = "<script language=javascript src=cupon.js></script>";
$P->strLeftMenu = marketting_menu();
$P->strContents = $Contents;
$P->Navigation = "HOME > 마케팅지원 > 쿠폰생성";
echo $P->PrintLayOut();

?>