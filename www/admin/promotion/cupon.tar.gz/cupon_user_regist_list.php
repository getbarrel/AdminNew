<?
include("../class/layout.class");

if($cupon_send_type_view == ""){
	$cupon_send_type_view = 1;	
}

if($mem_ix){
	$mem_ix_str = " and r.mem_ix = '".$mem_ix."' ";
}

$db = new MySQL();
//$db->query("Select * from ".TBL_MALLSTORY_CUPON_REGIST."");

	if($cupon_send_type_view == 2){
		/*
		$sql = "Select count(*) as total
		from ".TBL_MALLSTORY_CUPON." c , ".TBL_MALLSTORY_CUPON_PUBLISH." cp , ".TBL_MALLSTORY_CUPON_REGIST." r , ".TBL_MALLSTORY_MEMBER." m
		where r.mem_ix = m.code and cp.cupon_ix = c.cupon_ix and r.publish_ix = cp.publish_ix and open_yn = 1 $mem_ix_str
		";
		*/
		$sql = "Select count(*) as total
						from ".TBL_MALLSTORY_CUPON_REGIST." r , ".TBL_MALLSTORY_MEMBER." m 
						where r.mem_ix = m.code 
						and open_yn = 1  $mem_ix_str ";

	}else if($cupon_send_type_view == 3){
		/*
		$sql = "Select count(*) as total
						from ".TBL_MALLSTORY_CUPON." c , ".TBL_MALLSTORY_CUPON_PUBLISH." cp , ".TBL_MALLSTORY_CUPON_REGIST." r , ".TBL_MALLSTORY_MEMBER." m 
						where r.mem_ix = m.code and cp.cupon_ix = c.cupon_ix and r.publish_ix = cp.publish_ix 
						and use_yn = 1  $mem_ix_str ";
						*/
		$sql = "Select count(*) as total
						from ".TBL_MALLSTORY_CUPON_REGIST." r , ".TBL_MALLSTORY_MEMBER." m 
						where r.mem_ix = m.code 
						and use_yn = 1  $mem_ix_str ";
	}else{
		/*
		$sql = "Select count(*) as total
						from ".TBL_MALLSTORY_CUPON." c , ".TBL_MALLSTORY_CUPON_PUBLISH." cp , ".TBL_MALLSTORY_CUPON_REGIST." r , ".TBL_MALLSTORY_MEMBER." m 
						where r.mem_ix = m.code and cp.cupon_ix = c.cupon_ix and r.publish_ix = cp.publish_ix $mem_ix_str
						";
		*/				
		$sql = "Select count(*) as total
						from ".TBL_MALLSTORY_CUPON_REGIST." r, ".TBL_MALLSTORY_MEMBER." m 
						where r.mem_ix = m.code  $mem_ix_str
						";
	}
//echo $sql."<br><br>";
$db->query($sql);
$db->fetch();
$total = $db->dt[total];
/*
$db->query("Select * from ".TBL_MALLSTORY_CUPON_REGIST." where use_yn = 1 ");
$use_total = $db->total;
*/

$Script = "
<script language=javascript>
function SelectView(cupon_type_view){
	document.location.href = 'cupon_user_regist_list.php?mmode=".$mmode."&mem_ix=".$mem_ix."&cupon_send_type_view='+cupon_type_view
}
</script>";

$Contents = "
<table width='100%' border='0' cellpadding='0' cellspacing='0'>
  <tr>
		<td align='left' colspan=6 style='padding:0 0 10 0;'> ".GetTitleNavigation("쿠폰 발행 리스트", "마케팅지원 > 쿠폰 사용자 등록  리스트 ")."</td>
  </tr>  
  <tr>
    <td valign='top'>
      <table width='100%' border='0' cellpadding='2' cellspacing='0'>
        <tr>
          <td width='16'></td>
          <td width='100%' align=right>&nbsp;</td>
        </tr>
       
        <tr>
				    <td align='left' colspan=4 style='padding-bottom:20px;'> 
				    	<div class='tab'>
								<table class='s_org_tab' style='width:100%'>
								<col width=320>
								<col width=*>
								<tr>
									<td class='tab'>
										<table id='tab_01'  ".ReturnStringAfterCompare('1', $cupon_send_type_view, " class='on'").">
										<tr>
											<th class='box_01'></th>
											<td class='box_02' onclick='SelectView(1)' >모두보기</td>
											<th class='box_03'></th>
										</tr>
										</table>
										<table id='tab_02' ".ReturnStringAfterCompare('2', $cupon_send_type_view, " class='on'").">
										<tr>
											<th class='box_01'></th>
											<td class='box_02' onclick='SelectView(2)'>등록 목록 보기</td>
											<th class='box_03'></th>
										</tr>
										</table>
										<table id='tab_03' ".ReturnStringAfterCompare('3', $cupon_send_type_view, " class='on'").">
										<tr>
											<th class='box_01'></th>
											<td class='box_02' onclick='SelectView(3)'>사용 목록 보기</td>
											<th class='box_03'></th>
										</tr>
										</table>
									</td>
									<td style='text-align:right;vertical-align:bottom;padding:0 0 10 0'>						
										총건수 :&nbsp;<b>".$total."</b>
									</td>
								</tr>
								</table>	
							</div>
				    </td>
					</tr>	 
      </table>
    </td>
  </tr>
  <tr>
    <td height='5'></td>
  </tr>
  <tr>
    <td height='10'></td>
  </tr>
  <tr>
    <td valign='top'>
      <table width='100%' border='0' cellpadding='0' cellspacing='0'>
        <tr>
          <td valign='top'>
            <table width='100%'  border='0' cellpadding='10' cellspacing='1' bgcolor='#E9E9E9'>
              <tr>
                <td colspan='7' width='100%' height='3' bgcolor='#E9E9E9'></td>
              </tr>
              <tr bgcolor='#ffffff' align=center>
                <td class='con_c' bgcolor='white' nowrap>번호</td>
                <td class='con_c' bgcolor='white' nowrap>쿠폰발행일자</td>
                <td class='con_c' bgcolor='white' nowrap>쿠폰등록일자</td>
                <td class='con_c' bgcolor='white' nowrap>사용가능일자</td>
                <td class='con_c' bgcolor='white' nowrap>쿠폰내용</td>
                <td class='con_c' bgcolor='white' nowrap>쿠폰번호</td>
                <td width='30%' class='con_c' bgcolor='white' nowrap>아이디 / 이름</td>
                <td class='con_c' bgcolor='white' nowrap>등록</td>
                <td class='con_c' bgcolor='white' nowrap>사용</td>
              </tr>";

if($total < 1){
	$Contents .= "<tr bgcolor='#ffffff' height=50><td colspan=20 class='con_c' align=center> 등록된 쿠폰 정보가 없습니다. </td></tr>";
}else{	
$max = 10;
	
	if ($page == ''){
		$start = 0;
		$page  = 1;
	}else{
		$start = ($page - 1) * $max;
	}
	
	if($cupon_send_type_view == 2){
		/*
		$sql = "Select cp.cupon_no, cp.regdate as publish_regdate, cp.publish_ix, r.regdate as regist_regdate, r.open_yn, r.use_yn, 
		c.cupon_kind, m.name as mem_name, m.id as mem_id , r.mem_ix, r.use_sdate, r.use_date_limit
		from ".TBL_MALLSTORY_CUPON." c , ".TBL_MALLSTORY_CUPON_PUBLISH." cp , ".TBL_MALLSTORY_CUPON_REGIST." r , ".TBL_MALLSTORY_MEMBER." m 
		where r.mem_ix = m.code and cp.cupon_ix = c.cupon_ix and r.publish_ix = cp.publish_ix and open_yn = 1 $mem_ix_str
		order by r.regdate desc LIMIT $start, $max ";
		*/
		$sql = "Select cp.cupon_no, cp.regdate as publish_regdate, cp.publish_ix, r.regdate as regist_regdate, r.open_yn, r.use_yn, 
						c.cupon_kind, m.name as mem_name, m.id as mem_id , r.mem_ix, r.use_sdate, r.use_date_limit
						from (select * from ".TBL_MALLSTORY_CUPON_REGIST." r where open_yn = 1 $mem_ix_str order by r.regdate desc LIMIT $start, $max) r,
									".TBL_MALLSTORY_CUPON." c , ".TBL_MALLSTORY_CUPON_PUBLISH." cp , ".TBL_MALLSTORY_MEMBER." m 
						where r.mem_ix = m.code and cp.cupon_ix = c.cupon_ix and r.publish_ix = cp.publish_ix $mem_ix_str
						order by r.regdate desc  ";
						
	}else if($cupon_send_type_view == 3){
		/*
		$sql = "Select cp.cupon_no, cp.regdate as publish_regdate, cp.publish_ix, r.regdate as regist_regdate, r.open_yn, r.use_yn, 
						c.cupon_kind, m.name as mem_name, m.id as mem_id , r.mem_ix, r.use_sdate, r.use_date_limit
						from ".TBL_MALLSTORY_CUPON." c , ".TBL_MALLSTORY_CUPON_PUBLISH." cp , ".TBL_MALLSTORY_CUPON_REGIST." r ,  ".TBL_MALLSTORY_MEMBER." m
						where r.mem_ix = m.code and cp.cupon_ix = c.cupon_ix and r.publish_ix = cp.publish_ix and use_yn = 1 $mem_ix_str 
						order by r.regdate desc LIMIT $start, $max ";
		*/				
		$sql = "Select cp.cupon_no, cp.regdate as publish_regdate, cp.publish_ix, r.regdate as regist_regdate, r.open_yn, r.use_yn, 
						c.cupon_kind, m.name as mem_name, m.id as mem_id , r.mem_ix, r.use_sdate, r.use_date_limit
						from (select * from ".TBL_MALLSTORY_CUPON_REGIST." r where use_yn = 1 $mem_ix_str order by r.regdate desc LIMIT $start, $max) r,
									".TBL_MALLSTORY_CUPON." c , ".TBL_MALLSTORY_CUPON_PUBLISH." cp , ".TBL_MALLSTORY_MEMBER." m 
						where r.mem_ix = m.code and cp.cupon_ix = c.cupon_ix and r.publish_ix = cp.publish_ix $mem_ix_str
						order by r.regdate desc  ";
	}else{
		/*
		$sql = "Select cp.cupon_no, cp.regdate as publish_regdate, cp.publish_ix, r.regdate as regist_regdate, r.open_yn, r.use_yn, 
						c.cupon_kind, m.name as mem_name, m.id as mem_id , r.mem_ix, r.use_sdate, r.use_date_limit
						from ".TBL_MALLSTORY_CUPON." c , ".TBL_MALLSTORY_CUPON_PUBLISH." cp , ".TBL_MALLSTORY_CUPON_REGIST." r , ".TBL_MALLSTORY_MEMBER." m 
						where r.mem_ix = m.code and cp.cupon_ix = c.cupon_ix and r.publish_ix = cp.publish_ix $mem_ix_str
						order by r.regdate desc LIMIT $start, $max ";
		*/				
		$sql = "Select cp.cupon_no, cp.regdate as publish_regdate, cp.publish_ix, r.regdate as regist_regdate, r.open_yn, r.use_yn, 
						c.cupon_kind, m.name as mem_name, m.id as mem_id , r.mem_ix, r.use_sdate, r.use_date_limit
						from (select * from ".TBL_MALLSTORY_CUPON_REGIST." r where use_yn is not null $mem_ix_str order by r.regdate desc LIMIT $start, $max) r,
									".TBL_MALLSTORY_CUPON." c , ".TBL_MALLSTORY_CUPON_PUBLISH." cp , ".TBL_MALLSTORY_MEMBER." m 
						where r.mem_ix = m.code and cp.cupon_ix = c.cupon_ix and r.publish_ix = cp.publish_ix $mem_ix_str
						order by r.regdate desc  ";
	}
	//echo $sql."<br><br>";
	
	$db->query($sql);
	//echo $db->total;		
	for($i=0;$i < $db->total;$i++){
		$db->fetch($i);	
		$no = $total - ($page - 1) * $max - $i;
	
	
		if($db->dt[use_date_type] == 1){
			if($db->dt[publish_date_type] == 1){
				$date_type = '년';			
			}else if($db->dt[publish_date_type] == 2){
				$date_type = '개월';
			}else if($db->dt[publish_date_type] == 3){
				$date_type = '일';
			}
			$date_differ = $db->dt[publish_date_differ];
			$use_date_type = '발행일';		
		}else{
			if($db->dt[regist_date_type] == 1){
				$date_type = '년';			
			}else if($db->dt[regist_date_type] == 2){
				$date_type = '개월';
			}else if($db->dt[regist_date_type] == 3){
				$date_type = '일';
			}
			$date_differ = $db->dt[regist_date_differ];
			$use_date_type = '등록일';
		}
		
		
		
		if($db->dt[use_yn] == 1){
			$use_str = "<img src='../image/icon_o.gif' border='0'>";	
		}else{
			$use_str = "<img src='../image/icon_x.gif' border='0'>";	
		}
		
		if($db->dt[open_yn] == 1){
			$open_str = "<img src='../image/icon_o.gif' border='0'>";	
		}else{
			$open_str = "<img src='../image/icon_x.gif' border='0'>";	
		}
		
		if($db->dt[use_date] == ""){
			$use_date_str = "(-)";
		}else{
			$use_date_str = "(".$db->dt[use_date] .")";
		}
		
		$Contents .= "
	              <!--- // 목록 반복 시작 ---------->
	        	<tr bgcolor='#ffffff' align=center>
	                <td class='con_c' nowrap>".$no."</td>
	                <td class='con_c' align=center nowrap><font class='gray16'>".$db->dt[publish_regdate] ."</font></td>
	                <td class='con_c' align=center nowrap><font class='gray16'>".$db->dt[regist_regdate] ."</font></td>
	                <td class='con_c' align=center nowrap><font class='gray16'>".$db->dt[use_sdate] ."~".$db->dt[use_date_limit] ."</font></td>
	                <td class='con_c' nowrap><font class='yellow'>".$db->dt[cupon_kind] ."</font></td>
	                <td class='con_c' nowrap><font class='yellow'><a href=\"javascript:PopSWindow('cupon_register_user.php?mode=result&publish_ix=".$db->dt[publish_ix]."',550,600,'cupon_detail_pop');\" title='해당 쿠폰에 대한 발급된 사용자를 보여줍니다.' class=blue>".$db->dt[cupon_no] ."</a></font></td>
	                <td width='100%' class='con_c'><a href=\"javascript:PopSWindow('cupon_user_regist_list.php?mmode=pop&mem_ix=".$db->dt[mem_ix]."',900,600,'cupon_detail_pop');\" title='해당 사용자에게 발급된 쿠폰 목록을 보여줍니다.'  class=blue><font class='green'>".$db->dt[mem_id] ."/".$db->dt[mem_name] ."</font></a></td>
	                <td class='con_c' nowrap>".$open_str."</td>
	                <td class='con_c' nowrap>".$use_str."</td>
	              </tr>
	        			<!--tr bgcolor='#ffffff'>
	                <td colspan='5' class='con_l'>유효기간 : ".$use_date_type."로부터 ".$date_differ." ".$date_type."간&nbsp;&nbsp;(결제가격이 ".number_format($db->dt[publish_condition_price],0)." 원 이상인 상품에 사용가능)<br>사용가능상품 : ".$apply_str." 사용가능.</td>
	              </tr-->";
	
	
	$apply_str='';
	}//for 
$Contents .= "
		 <tr height=50 bgcolor='#ffffff'>
		    <td align='center' colspan='10'>".page_bar($total, $page, $max,"&mmode=$mmode&mem_ix=$mem_ix&cupon_send_type_view=$cupon_send_type_view",'')."</td>
		  </tr>";

}

$Contents .= "
              <!--- 목록 반복 끝 // ---------->
            </table>
          </td>
        </tr>
      </table>
    </td>
  </tr>
  <tr>
    <td height='20' valign='top'></td>
  </tr>
 
</table>";

$help_text = "
<table cellpadding=0 cellspacing=0 class='small' >
	<col width=8>
	<col width=*>
	<tr><td ><img src='/admin/image/icon_list.gif' ></td><td class='small' >쿠폰에 대한 사용자들의 등록 목록 입니다.</td></tr>
	<tr><td valign=top><img src='/admin/image/icon_list.gif' ></td><td class='small' >쿠폰번호를 클릭하시면 해당 쿠폰에 대한 사용자의 발급 목록을 확인 하실 수 있습니다.</td></tr>
	<tr><td valign=top><img src='/admin/image/icon_list.gif' ></td><td class='small' >같은 쿠폰은 중복 발급할 수 없습니다.</td></tr>
</table>
";


$Contents .=  HelpBox("쿠폰 사용자 발급 리스트", $help_text);

if($mmode == "pop"){		
	$P = new ManagePopLayOut();
	$P->addScript = $Script;
	
	$P->strLeftMenu = marketting_menu();
	$P->strContents = $Contents;
	$P->Navigation = "HOME > 마케팅지원 > 쿠폰 사용자 발급 리스트";
	$P->NaviTitle = "쿠폰 사용자 발급 리스트";
	echo $P->PrintLayOut();
}else{
	
	$P = new LayOut();
	$P->addScript = $Script;
	
	$P->strLeftMenu = marketting_menu();
	$P->strContents = $Contents;
	$P->Navigation = "HOME > 마케팅지원 > 쿠폰 사용자 발급 리스트";
	echo $P->PrintLayOut();
}
?>
