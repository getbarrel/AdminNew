<?
include("../include/admin.util.php");
include("$DOCUMENT_ROOT/class/mysql.class");
/*
print_r($_POST);
exit;
*/
session_start();

$db = new MySQL();
function GetCuponNo(){
	$mdb = new MySQL();
	$cupon_no =  "MSCP".date("ymd").rand(1000000,9999999);
	
	$mdb->query("select cupon_no from ".TBL_MALLSTORY_CUPON_PUBLISH." where cupon_no = '$cupon_no'");
	
	If($mdb->total){
		GetCuponNo();
	}else{
		return $cupon_no;	
	}
}
if($act == "publish"){
	$cupon_no =  GetCuponNo();
	
	$use_sdate = $FromYY.$FromMM.$FromDD;
	$use_edate = $ToYY.$ToMM.$ToDD;
	

	
	$sql = "insert into ".TBL_MALLSTORY_CUPON_PUBLISH." 
		   (publish_ix,cupon_ix,cupon_no, use_date_type,use_sdate, use_edate, use_product_type , publish_date_differ,publish_date_type,regist_date_differ,regist_date_type,publish_condition_price,publish_type,mem_ix,regdate) 
		   values
		   ('','$cupon_ix','$cupon_no','$use_date_type','$use_sdate','$use_edate','$use_product_type ','$publish_date_differ','$publish_date_type','$regist_date_differ','$regist_date_type','$publish_condition_price','$publish_type','$mem_ix',NOW())";
	
	
	$db->query($sql);
	
	
		$db->query("Select publish_ix from ".TBL_MALLSTORY_CUPON_PUBLISH." where publish_ix = LAST_INSERT_ID()");
		$db->fetch();
		$publish_ix = $db->dt[publish_ix];
		/*
		if($use_date_type == 1){
			if($publish_date_type == 1){
				$publish_year = date("Y") + $publish_date_differ;
			}else{
				$publish_year = date("Y");
			}
			if($publish_date_type == 2){
				$publish_month = date("m") + $publish_date_differ;
			}else{
				$publish_month = date("m");
			}
			if($publish_date_type == 3){
				$publish_day = date("d") + $publish_date_differ;
			}else{
				$publish_day = date("d");
			}
			
			$use_date_limit = mktime(0,0,0,$publish_month,$publish_day,$publish_year);
			
			//$event_date = mktime(0,0,0,$event_meonth,$event_day+$order[end_date_differ],$evet_year);
			
		}else{
			if($regist_date_type == 1){
				$regist_year = date("Y") + $regist_date_differ;
			}else{
				$regist_year = date("Y");
			}
			if($regist_date_type == 2){
				$regist_month = date("m") + $regist_date_differ;
			}else{
				$regist_month = date("m");
			}
			if($regist_date_type == 3){
				$regist_day = date("d") + $regist_date_differ;
			}else{
				$regist_day = date("d");
			}
			
			$use_date_limit = mktime(0,0,0,$regist_month,$regist_day,$regist_year);
		}
		*/
		
		
		
		if($use_product_type == "3"){
			if(!$db->mysql_table_exists("mallstory_cupon_relation_product")){
				$sql = "CREATE TABLE `mallstory_cupon_relation_product` (
				  `cpr_ix` int(8)  default NULL auto_increment,
				  `publish_ix` int(4) NOT NULL,
				  `pid` int(6) NOT NULL,
				  `regdate` datetime NOT NULL default '0000-00-00 00:00:00',
				  PRIMARY KEY  (`cpr_ix`)
				) TYPE=MyISAM COMMENT='쿠폰관련상품'  ;";
	
				$db->query($sql);		
			}
			//$db->query("delete from mallstory_cupon_relation_product where publish_ix='$publish_ix'");
			for($i=0;$i < count($rpid);$i++){
				$db->query("Select publish_ix from mallstory_cupon_relation_product where pid = '".$rpid[$i]."' and publish_ix = '".$publish_ix."' ");
				
				if(!$db->total){
					$sql = "insert into mallstory_cupon_relation_product (cpr_ix,publish_ix,pid, regdate) 
						values ('','".$publish_ix."','".$rpid[$i]."',NOW())";
						
					$db->query($sql);
				}
			}
			$db->query("delete from mallstory_cupon_relation_category where  publish_ix = '".$publish_ix."' ");
		}else if($use_product_type == "2"){
				if(!$db->mysql_table_exists("mallstory_cupon_relation_category")){
					$sql = "CREATE TABLE `mallstory_cupon_relation_category` (
					  `cpc_ix` int(8)  default NULL auto_increment,
					  `publish_ix` int(4) NOT NULL,
					  `cid` int(6) NOT NULL,
					  `depth` int(1) NOT NULL,
					  `regdate` datetime NOT NULL default '0000-00-00 00:00:00',
					  PRIMARY KEY  (`cpc_ix`)
						) TYPE=MyISAM COMMENT='쿠폰관련카테고리'  ;";
						
					$db->query($sql);		
				}
				
				
				for($i=0;$i < count($category);$i++){
					$sql = "Select publish_ix from mallstory_cupon_relation_category where cid = '".$category[$i]."' and publish_ix = '".$publish_ix."' ";
					//echo $sql;
					$db->query($sql);
					
					if(!$db->total){
						$sql = "insert into mallstory_cupon_relation_category (cpc_ix,publish_ix,cid, depth, regdate) 
										values ('','".$publish_ix."','".$category[$i]."','".$depth[$i]."',NOW())";
					//	echo $sql;
						$db->query($sql);
					}
				}
			
			$db->query("delete from mallstory_cupon_relation_product where  publish_ix = '".$publish_ix."' ");
		}else if($use_product_type == "4"){			
					$sql = "insert into mallstory_cupon_relation_brand (crb_ix,publish_ix,b_ix, regdate) 
									values ('','".$publish_ix."','".$brand."',NOW())";
					$db->query($sql);
			
		}
			
		/*
		if($publish_type == "1"){
			$use_date_limit = date("Y-m-d",$use_date_limit);
			$sql2 = "insert into ".TBL_MALLSTORY_CUPON_REGIST." (regist_ix,publish_ix,mem_ix,open_yn,use_yn,use_date_limit, regdate) 
					values 
					('','".$publish_ix."','$mem_ix','1','0','$use_date_limit',NOW())";
					
			//echo $sql2;
					
			$db->query($sql2);
		}
		*/
	if($mmode== "pop"){
		echo "<Script>parent.document.location.href='cupon_publish_list.php?mmode=$mmode'</Script>";
	}else{	
		echo "<Script>parent.document.location.href='cupon_publish_list.php'</Script>";
	}
	//echo "<Script>parent.document.location.reload();</Script>";
	exit;	
}


if($act == "regist_search_update"){
		$sql = "Select publish_ix,use_date_type,publish_date_differ,publish_type,publish_date_type , regist_date_type, regist_date_differ,use_sdate, use_edate
						from ".TBL_MALLSTORY_CUPON_PUBLISH." 
						where publish_ix = '".$publish_ix."'";
		$db->query($sql);
		$db->fetch();
		$publish_ix = $db->dt[publish_ix];
		
		if($db->dt[use_date_type] == 1){
			if($db->dt[publish_date_type] == 1){
				$publish_year = date("Y") + $db->dt[publish_date_differ];
			}else{
				$publish_year = date("Y");
			}
			if($db->dt[publish_date_type] == 2){
				$publish_month = date("m") + $db->dt[publish_date_differ];
			}else{
				$publish_month = date("m");
			}
			if($db->dt[publish_date_type] == 3){
				$publish_day = date("d") + $db->dt[publish_date_differ];
			}else{
				$publish_day = date("d");
			}
			$use_sdate = time();
			$use_date_limit = mktime(0,0,0,$publish_month,$publish_day,$publish_year);
			
			//$event_date = mktime(0,0,0,$event_meonth,$event_day+$order[end_date_differ],$evet_year);
			
		}else if($db->dt[use_date_type] == 2){
			if($db->dt[regist_date_type] == 1){
				$regist_year = date("Y") + $db->dt[regist_date_differ];
			}else{
				$regist_year = date("Y");
			}
			if($db->dt[regist_date_type] == 2){
				$regist_month = date("m") + $db->dt[regist_date_differ];
			}else{
				$regist_month = date("m");
			}
			if($db->dt[regist_date_type] == 3){
				$regist_day = date("d") + $db->dt[regist_date_differ];
			}else{
				$regist_day = date("d");
			}
			$use_sdate = time();
			$use_date_limit = mktime(0,0,0,$regist_month,$regist_day,$regist_year);
		}else if($db->dt[use_date_type] == 3){		
			$use_sdate = mktime(0,0,0,substr($db->dt[use_sdate],4,2),substr($db->dt[use_sdate],6,2),substr($db->dt[use_sdate],0,4));
			$use_date_limit = mktime(0,0,0,substr($db->dt[use_edate],4,2),substr($db->dt[use_edate],6,2),substr($db->dt[use_edate],0,4));
		}

		$where = " where code != '' and mm.gp_ix = mg.gp_ix and gp_level != 0 ";
		
		if($search_type != "" && $search_text != ""){	
			if($search_type == "jumin"){
				$search_text = substr($search_text,0,6)."-".md5(substr($search_text,6,7));
				$where .= " and jumin = '$search_text' ";
			}else{
				$where .= " and $search_type LIKE  '%$search_text%' ";
			}
		}
		
		if($gp_ix != ""){
			$where .= " and mm.gp_ix = '".$gp_ix."' ";
		}	
		
		$startDate = $FromYY.$FromMM.$FromDD;
		$endDate = $ToYY.$ToMM.$ToDD;
			
		if($startDate != "" && $endDate != ""){	
			if($publish_div == "2"){
				$where .= " and  date_format(mm.date,'%Y%m%d') between  $startDate and $endDate ";
			}else if($publish_div == "3"){
				$where .= " and  date_format(mm.recent_order_date,'%Y%m%d') between  $startDate and $endDate ";
			}else if($publish_div == "4"){
				$where .= " and  date_format(mm.last,'%Y%m%d') between  $startDate and $endDate ";
			}
		}
		
		$use_sdate = date("Ymd",$use_sdate);
		$use_date_limit = date("Ymd",$use_date_limit);
		
		if($dupe_check){
			$sql = "insert into ".TBL_MALLSTORY_CUPON_REGIST."  select '' as regist_ix , '".$publish_ix."' as publish_ix, code,1,0,
							'$use_sdate','$use_date_limit',null,null, NOW() , null, null
							from ".TBL_MALLSTORY_MEMBER." mm , ".TBL_MALLSTORY_GROUPINFO." mg 
							$where ";
			$db->query($sql);
		}else{
			$sql = "select code,name,id,mail, pcs ,perm from ".TBL_MALLSTORY_MEMBER." mm , ".TBL_MALLSTORY_GROUPINFO." mg 
							$where ";
		
			$db->query($sql);
			$meminfos = $db->fetchall();
			
			
			for($i=0;$i< count($meminfos) ;$i++){
				
				
				$db->query("Select publish_ix from ".TBL_MALLSTORY_CUPON_REGIST." where publish_ix='$publish_ix' and mem_ix = '".$meminfos[$i][code]."' ");
				
				if(!$db->total){
					$sql2 = "insert into ".TBL_MALLSTORY_CUPON_REGIST." (regist_ix,publish_ix,mem_ix,open_yn,use_yn,use_sdate,use_date_limit, regdate) 
							values 
							('','".$publish_ix."','".$meminfos[$i][code]."','1','0','$use_sdate','$use_date_limit',NOW())";
							 
				//echo $sql2;
				$db->query($sql2);
				}
			}
		}
		echo "<script>alert('정상적으로 등록 되었습니다.');document.location.href='cupon_register_user.php?publish_ix=".$publish_ix."&mode=result'</script>";
}



if($act == "regist_update"){
	$sql = "Select publish_ix,use_date_type,publish_date_differ,publish_type,publish_date_type ,regist_date_type, regist_date_differ, use_sdate, use_edate
					from ".TBL_MALLSTORY_CUPON_PUBLISH." 
					where publish_ix = '".$publish_ix."'";
	$db->query($sql);
	$db->fetch();
	$publish_ix = $db->dt[publish_ix];
	//print_r($_POST);
	//echo $db->dt[use_date_type].$db->dt[publish_date_type];
	//exit;
	if($db->dt[use_date_type] == 1){
		if($db->dt[publish_date_type] == 1){
			$publish_year = date("Y") + $db->dt[publish_date_differ];
		}else{
			$publish_year = date("Y");
		}
		if($db->dt[publish_date_type] == 2){
			$publish_month = date("m") + $db->dt[publish_date_differ];
		}else{
			$publish_month = date("m");
		}
		if($db->dt[publish_date_type] == 3){
			$publish_day = date("d") + $db->dt[publish_date_differ];
		}else{
			$publish_day = date("d");
		}
		$use_sdate = time();
		$use_date_limit = mktime(0,0,0,$publish_month,$publish_day,$publish_year);
		
		//$event_date = mktime(0,0,0,$event_meonth,$event_day+$order[end_date_differ],$evet_year);
		
	}else if($db->dt[use_date_type] == 2){
		if($db->dt[regist_date_type] == 1){
			$regist_year = date("Y") + $db->dt[regist_date_differ];
		}else{
			$regist_year = date("Y");
		}
		if($db->dt[regist_date_type] == 2){
			$regist_month = date("m") + $db->dt[regist_date_differ];
		}else{
			$regist_month = date("m");
		}
		if($db->dt[regist_date_type] == 3){
			$regist_day = date("d") + $db->dt[regist_date_differ];
		}else{
			$regist_day = date("d");
		}
		$use_sdate = time();
		$use_date_limit = mktime(0,0,0,$regist_month,$regist_day,$regist_year);
	}else if($db->dt[use_date_type] == 3){		
		$use_sdate = mktime(0,0,0,substr($db->dt[use_sdate],4,2),substr($db->dt[use_sdate],6,2),substr($db->dt[use_sdate],0,4));
		$use_date_limit = mktime(0,0,0,substr($db->dt[use_edate],4,2),substr($db->dt[use_edate],6,2),substr($db->dt[use_edate],0,4));
		
	}

	if($db->dt[publish_type] == "1" || $db->dt[publish_type] == "2"){
		$use_sdate = date("Ymd",$use_sdate);
		$use_date_limit = date("Ymd",$use_date_limit);
		for($i=0;$i<count($code);$i++){			
			$db->query("Select publish_ix from ".TBL_MALLSTORY_CUPON_REGIST." where publish_ix='$publish_ix' and mem_ix = '".$code[$i]."' ");
			
			if(!$db->total){
				$sql2 = "insert into ".TBL_MALLSTORY_CUPON_REGIST." (regist_ix,publish_ix,mem_ix,open_yn,use_yn,use_sdate, use_date_limit, regdate) 
						values 
						('','".$publish_ix."','".$code[$i]."','1','0','$use_sdate','$use_date_limit',NOW())";
						
				//echo $sql2;
						
				$db->query($sql2);
			}
		}
	}
	echo "<script>alert('정상적으로 등록 되었습니다.');document.location.href='cupon_register_user.php?publish_ix=".$publish_ix."&mode=result'</script>";
	exit;
}
if($act == "publish_update"){
	
	$use_sdate = $FromYY.$FromMM.$FromDD;
	$use_edate = $ToYY.$ToMM.$ToDD;
	
	if($use_date_type == 1){
			if($publish_date_type == 1){
				$publish_year = date("Y") + $publish_date_differ;
			}else{
				$publish_year = date("Y");
			}
			if($publish_date_type == 2){
				$publish_month = date("m") + $publish_date_differ;
			}else{
				$publish_month = date("m");
			}
			if($publish_date_type == 3){
				$publish_day = date("d") + $publish_date_differ;
			}else{
				$publish_day = date("d");
			}
			
			$use_date_limit = mktime(0,0,0,$publish_month,$publish_day,$publish_year);
			
			//$event_date = mktime(0,0,0,$event_meonth,$event_day+$order[end_date_differ],$evet_year);
			
		}else{
			if($regist_date_type == 1){
				$regist_year = date("Y") + $regist_date_differ;
			}else{
				$regist_year = date("Y");
			}
			if($regist_date_type == 2){
				$regist_month = date("m") + $regist_date_differ;
			}else{
				$regist_month = date("m");
			}
			if($regist_date_type == 3){
				$regist_day = date("d") + $regist_date_differ;
			}else{
				$regist_day = date("d");
			}
			
			$use_date_limit = mktime(0,0,0,$regist_month,$regist_day,$regist_year);
		}
	
		$sql = "update mallstory_cupon_publish set 
						cupon_ix='$cupon_ix',use_date_type='$use_date_type',use_sdate='$use_sdate',use_edate='$use_edate',use_product_type='$use_product_type',publish_date_differ='$publish_date_differ',publish_date_type='$publish_date_type',regist_date_differ='$regist_date_differ',regist_date_type='$regist_date_type',publish_condition_price='$publish_condition_price',publish_type='$publish_type',mem_ix='$mem_ix'
						where publish_ix='$publish_ix' ";
		
		$db->query($sql);	
		
		if($use_product_type == "3"){
			$db->query("update mallstory_cupon_relation_product set insert_yn = 'N' where publish_ix='$publish_ix' ");
			
			for($i=0;$i < count($rpid);$i++){
				$db->query("Select publish_ix from mallstory_cupon_relation_product where publish_ix='$publish_ix' and pid = '".$rpid[$i]."' ");
				
				if(!$db->total){
					$sql = "insert into mallstory_cupon_relation_product (cpr_ix,publish_ix,pid, vieworder, insert_yn, regdate) 
									values ('','".$publish_ix."','".$rpid[$i]."','".($i+1)."','Y', NOW())";	
					$db->query($sql);
					//echo $sql;
				}else{
					$db->query("update mallstory_cupon_relation_product set vieworder='".($i+1)."', insert_yn = 'Y' where publish_ix='$publish_ix' and pid = '".$rpid[$i]."' ");	
				}
				
			}			
			$db->query("delete from mallstory_cupon_relation_product where publish_ix='".$publish_ix."' and insert_yn = 'N' ");		
			$db->query("delete from mallstory_cupon_relation_category where  publish_ix = '".$publish_ix."' ");
			
		}else if($use_product_type == "2"){
			$db->query("update mallstory_cupon_relation_category set insert_yn = 'N' where publish_ix='$publish_ix' ");
			for($i=0;$i < count($category);$i++){
				$sql = "Select publish_ix from mallstory_cupon_relation_category where cid = '".$category[$i]."' and publish_ix = '".$publish_ix."' ";
				//echo $sql;
				$db->query($sql);
				
				if(!$db->total){
					$sql = "insert into mallstory_cupon_relation_category (cpc_ix,publish_ix,cid, depth, insert_yn, regdate) 
									values ('','".$publish_ix."','".$category[$i]."','".$depth[$i]."','Y',NOW())";
				//	echo $sql;
					$db->query($sql);
				}else{
					$db->query("update mallstory_cupon_relation_category set insert_yn = 'Y' where publish_ix='$publish_ix' and cid='".$category[$i]."' ");	
				}
			}
			$db->query("delete from mallstory_cupon_relation_category where publish_ix='".$publish_ix."' and insert_yn = 'N' ");		
			$db->query("delete from mallstory_cupon_relation_product where  publish_ix = '".$publish_ix."' ");
		}else if($use_product_type == "4"){
			
				$sql = "Select publish_ix from mallstory_cupon_relation_brand where b_ix = '".$brand."' and publish_ix = '".$publish_ix."' ";
				//echo $sql;
				$db->query($sql);
				
				if(!$db->total){
					$sql = "insert into mallstory_cupon_relation_brand (crb_ix,publish_ix,b_ix, regdate) 
									values ('','".$publish_ix."','".$brand."',NOW())";
				//	echo $sql;
					$db->query($sql);
				}else{
					$db->query("update mallstory_cupon_relation_brand set b_ix = '".$brand."' where publish_ix='$publish_ix'  ");	
				}
		
		}
			
			

		/*
		if($db->dt[publish_type] == "1"){
			for($i=0;$i<count($code);$i++){
				$use_date_limit = date("Y-m-d",$use_date_limit);
				
				$db->query("select * from ".TBL_MALLSTORY_CUPON_REGIST." where publish_ix = '".$publish_ix."' and mem_ix = '".$code[$i]."' ");
				if(!$db->total){
					$sql2 = "insert into ".TBL_MALLSTORY_CUPON_REGIST." (regist_ix,publish_ix,mem_ix,open_yn,use_yn,use_date_limit, regdate) 
							values 
							('','".$publish_ix."','".$mem_ix."','1','0','$use_date_limit',NOW())";
							
					//echo $sql2;
							
					$db->query($sql2);
				}
			}
		}
		*/
		
		if($mmode== "pop"){
			echo "<Script>parent.document.location.href='cupon_publish_list.php?mmode=$mmode'</Script>";
		}else{	
			echo "<Script>parent.document.location.href='cupon_publish_list.php'</Script>";
		}	
		//echo "<Script>document.location.href='cupon_publish_list.php'</Script>";
		//echo "<Script>parent.document.location.reload();</Script>";
		exit;
}

if($act == "insert"){

	$sql = "insert into ".TBL_MALLSTORY_CUPON." (cupon_ix,cupon_kind,cupon_sale_value, cupon_sale_type, regdate) values ('','$cupon_kind','$cupon_sale_value', '$cupon_sale_type', NOW())";
	
	$db->query($sql);
		
	if ($cupon_img_size > 0){
		//$cupon_imgname = "bgm_cl_".$db->dt[0].".".substr($cupon_img_name,-3);
		//copy($cupon_img, "$DOCUMENT_ROOT".$admin_config[mall_data_root]."/images/cupon/".$cupon_imgname);
		
		$db->query("SELECT cupon_ix FROM ".TBL_MALLSTORY_CUPON." WHERE cupon_ix=LAST_INSERT_ID()");
		$db->fetch();
		//$db->query("update cardstory_card_backmusic set cupon_img = '$cupon_imgname' WHERE bgm_ix='".$db->dt[0]."'");	
		
		
		copy($cupon_img, "$DOCUMENT_ROOT".$admin_config[mall_data_root]."/images/cupon/cupon_".$db->dt[0].".gif");
	}
	
	echo "<Script>document.location.href='cupon_regist_list.php'</Script>";
	exit;	
}

if($act == "update"){
	if ($cupon_img_size > 0){
	
		copy($cupon_img, "$DOCUMENT_ROOT".$admin_config[mall_data_root]."/images/cupon/cupon_".$cupon_ix.".gif");
		
	}
	
	$sql = "update ".TBL_MALLSTORY_CUPON." set cupon_kind='$cupon_kind', cupon_sale_value = '$cupon_sale_value', cupon_sale_type = '$cupon_sale_type' 
					where cupon_ix='$cupon_ix'";	
	
	
	$db->query($sql);
	
	echo "<Script>document.location.href='cupon_regist_list.php'</Script>";
	exit;
}

if($act == "delete"){
	
	if($db->total){
		$db->fetch();
		if (file_exists("$DOCUMENT_ROOT".$admin_config[mall_data_root]."/images/cupon/cupon_".$cupon_ix.".gif")){
			unlink("$DOCUMENT_ROOT".$admin_config[mall_data_root]."/images/cupon/cupon_".$cupon_ix.".gif");
		}	
	}
	$sql_regist = "select count(*) as cnt from mallstory_cupon_regist a,mallstory_cupon_publish  b 
					where a.publish_ix = b.publish_ix 
					and b.cupon_ix = '$cupon_ix' and a.use_date_limit > now()";
	
	$db->query($sql_regist);
	$db->fetch();

	if($db->dt[0]){
		echo "<script language='javascript'>alert('삭제할수 없습니다.');</script>";
	}else{
		$db->query("delete from ".TBL_MALLSTORY_CUPON." where cupon_ix ='$cupon_ix'");		
		$db->query("delete from ".TBL_MALLSTORY_CUPON_PUBLISH." where cupon_ix ='$cupon_ix'");		
	}
	echo "<Script>document.location.href='cupon_regist_list.php'</Script>";
}


if($act == "regist_delete"){
	
	for($i=0;$i < count($code);$i++){						
			$db->query("delete from ".TBL_MALLSTORY_CUPON_REGIST." where publish_ix='".$publish_ix."' and mem_ix = '".$code[$i]."'");			
	}
			
	echo "<script>alert('정상적으로 발급 취소 되었습니다.');document.location.href='cupon_register_user.php?publish_ix=".$publish_ix."&mode=result'</script>";
	exit;
}

if($act == "publish_delete"){	
	$db->query("select publish_ix from ".TBL_MALLSTORY_CUPON_REGIST." where publish_ix='$publish_ix' and use_yn = '0'");
	
	if($db->total){
		echo "<Script>alert('사용되지 않은 쿠폰이 존재합니다. 쿠폰등록을 취소한후 삭제하시기 바랍니다.');</Script>";
		exit;
	}else{
		$db->query("delete from ".TBL_MALLSTORY_CUPON_PUBLISH." where publish_ix='$publish_ix'");
		$db->query("delete from ".TBL_MALLSTORY_CUPON_REGIST." where publish_ix='$publish_ix'");
		$db->query("delete from mallstory_cupon_relation_product where  publish_ix = '".$publish_ix."' ");
		$db->query("delete from mallstory_cupon_relation_category where  publish_ix = '".$publish_ix."' ");
		
		$db->query("delete from mallstory_cupon_relation_product where publish_ix='$publish_ix'");
		
		echo "<Script>parent.document.location.reload();</Script>";		
		exit;
	}
	
	
}

?>